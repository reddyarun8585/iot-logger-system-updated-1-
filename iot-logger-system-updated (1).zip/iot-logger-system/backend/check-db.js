require('dotenv').config();
const mysql = require('mysql2/promise');
const p = process.env;
mysql.createConnection({ host: p.DB_HOST || 'localhost', port: p.DB_PORT || 3306, user: p.DB_USER, password: p.DB_PASSWORD })
  .then((c) => { console.log('CONNECTED OK'); return c.end(); })
  .catch((e) => console.log('FAILED:', e.code, e.message));
