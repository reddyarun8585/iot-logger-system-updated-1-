CREATE DATABASE IF NOT EXISTS iot_logger_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE iot_logger_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  company VARCHAR(160) NULL,
  address VARCHAR(255) NULL,
  role ENUM('Admin','Staff','Customer') NOT NULL DEFAULT 'Customer',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role), INDEX idx_users_name (full_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS data_loggers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  model_number VARCHAR(60) NOT NULL UNIQUE,
  image_url VARCHAR(255) NULL,
  description TEXT NULL,
  logger_type VARCHAR(80) NOT NULL,
  channels INT NOT NULL DEFAULT 1,
  measurement_range VARCHAR(160) NULL,
  connectivity ENUM('Wi-Fi','Bluetooth','USB','Ethernet','Cellular') NOT NULL,
  stock_quantity INT NOT NULL DEFAULT 0,
  unit_price DECIMAL(12,2) NOT NULL,
  discount_price DECIMAL(12,2) NULL,
  status ENUM('Active','Inactive','Discontinued') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dl_status (status), INDEX idx_dl_name (name), INDEX idx_dl_type (logger_type),
  CONSTRAINT chk_stock CHECK (stock_quantity >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_code VARCHAR(40) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  booking_date DATE NOT NULL,
  delivery_name VARCHAR(120) NOT NULL,
  delivery_phone VARCHAR(30) NOT NULL,
  delivery_address VARCHAR(255) NOT NULL,
  special_instructions TEXT NULL,
  status ENUM('Pending','Confirmed','Processing','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_bk_status (status), INDEX idx_bk_user (user_id), INDEX idx_bk_date (booking_date),
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS booking_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  data_logger_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  discount_price DECIMAL(12,2) NULL,
  INDEX idx_bi_booking (booking_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  FOREIGN KEY (data_logger_id) REFERENCES data_loggers(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(40) NOT NULL UNIQUE,
  booking_id INT NULL UNIQUE,
  user_id INT NOT NULL,
  status ENUM('Pending','Confirmed','Processing','Shipped','Completed','Cancelled') NOT NULL DEFAULT 'Confirmed',
  payment_status ENUM('Unpaid','Partial','Paid','Refunded') NOT NULL DEFAULT 'Unpaid',
  subtotal DECIMAL(12,2) NOT NULL,
  discount_total DECIMAL(12,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  shipping_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  grand_total DECIMAL(12,2) NOT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_or_status (status), INDEX idx_or_user (user_id), INDEX idx_or_created (created_at),
  FOREIGN KEY (booking_id) REFERENCES bookings(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  data_logger_id INT NOT NULL,
  product_name VARCHAR(160) NOT NULL,
  model_number VARCHAR(60) NOT NULL,
  image_url VARCHAR(255) NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  discount_price DECIMAL(12,2) NULL,
  line_total DECIMAL(12,2) NOT NULL,
  INDEX idx_oi_order (order_id), INDEX idx_oi_product (data_logger_id),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (data_logger_id) REFERENCES data_loggers(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  status VARCHAR(30) NOT NULL,
  note VARCHAR(255) NULL,
  changed_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_oh_order (order_id),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS call_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NULL,
  customer_name VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  call_datetime DATETIME NOT NULL,
  purpose VARCHAR(200) NOT NULL,
  status ENUM('Scheduled','Completed','Missed','Follow-up Required') NOT NULL DEFAULT 'Scheduled',
  notes TEXT NULL,
  next_followup DATE NULL,
  assigned_staff_id INT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_cr_customer (customer_id), INDEX idx_cr_status (status), INDEX idx_cr_dt (call_datetime),
  FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_staff_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data_logger_id INT NOT NULL,
  change_qty INT NOT NULL,
  balance_after INT NOT NULL,
  type ENUM('Sale','Cancellation','Adjustment','Restock','Initial') NOT NULL,
  reference VARCHAR(60) NULL,
  note VARCHAR(255) NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_it_product (data_logger_id),
  FOREIGN KEY (data_logger_id) REFERENCES data_loggers(id)
) ENGINE=InnoDB;

-- Payment records only track status/reference. Card details are never stored.
CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  method ENUM('Cash','Bank Transfer','UPI','Card','Other') NOT NULL DEFAULT 'Bank Transfer',
  status ENUM('Pending','Completed','Failed','Refunded') NOT NULL DEFAULT 'Completed',
  reference VARCHAR(100) NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pay_order (order_id),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  `key` VARCHAR(60) PRIMARY KEY,
  `value` VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
INSERT IGNORE INTO settings (`key`,`value`) VALUES ('tax_rate','18'),('shipping_flat','500'),('low_stock_threshold','10'),('company_name','SensorLink Instruments');
