// Creates the database/tables and (when empty) loads demo data. Use --reset to drop and rebuild everything.
require('dotenv').config();
const fs = require('fs'), path = require('path'), mysql = require('mysql2/promise'), bcrypt = require('bcryptjs');

const DB = process.env.DB_NAME || 'iot_logger_db';
const palette = ['#0b2545', '#13315c', '#1d6fdc', '#3d8bfd'];
function svg(model, type, i) {
  const c = palette[i % 4];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="420" viewBox="0 0 640 420"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#eef4ff"/><stop offset="1" stop-color="#dbe8ff"/></linearGradient></defs>
<rect width="640" height="420" fill="url(#g)"/><rect x="170" y="90" width="300" height="200" rx="18" fill="${c}"/><rect x="195" y="115" width="140" height="70" rx="8" fill="#0a1a33"/>
<polyline points="205,170 225,150 245,162 270,130 295,155 320,140" fill="none" stroke="#5fd1ff" stroke-width="4"/>
<circle cx="415" cy="140" r="9" fill="#37e29a"/><circle cx="440" cy="140" r="9" fill="#ffb84d"/>
<g fill="#9fb6d9"><rect x="195" y="215" width="40" height="40" rx="5"/><rect x="245" y="215" width="40" height="40" rx="5"/><rect x="295" y="215" width="40" height="40" rx="5"/><rect x="345" y="215" width="40" height="40" rx="5"/></g>
<text x="320" y="335" font-family="Arial,sans-serif" font-size="26" font-weight="700" text-anchor="middle" fill="#0b2545">${model}</text>
<text x="320" y="365" font-family="Arial,sans-serif" font-size="16" text-anchor="middle" fill="#3b5683">${type}</text></svg>`;
}

(async () => {
  const reset = process.argv.includes('--reset');
  const conn = await mysql.createConnection({ host: process.env.DB_HOST, port: process.env.DB_PORT || 3306, user: process.env.DB_USER, password: process.env.DB_PASSWORD, multipleStatements: true });
  if (reset) { await conn.query(`DROP DATABASE IF EXISTS \`${DB}\``); console.log('Dropped database', DB); }
  const sql = fs.readFileSync(path.join(__dirname, '../sql/schema.sql'), 'utf8').replace(/iot_logger_db/g, DB);
  await conn.query(sql); await conn.changeUser({ database: DB });
  console.log('Schema ready');
  const [[{ n }]] = await conn.query('SELECT COUNT(*) n FROM users');
  if (n > 0) { console.log('Data already present - skipping demo seed (use db:reset to rebuild).'); return conn.end(); }
  await conn.end();

  const { pool, withTx } = require('../src/config/db');
  const bookingService = require('../src/services/bookingService'), orderService = require('../src/services/orderService');
  const hash = (p) => bcrypt.hashSync(p, 12);
  const users = [
    ['Aarav Mehta', 'admin@iotlogger.com', 'Admin@123', '+91 98765 00001', 'SensorLink Instruments', 'Hyderabad, Telangana', 'Admin'],
    ['Priya Nair', 'staff@iotlogger.com', 'Staff@123', '+91 98765 00002', 'SensorLink Instruments', 'Hyderabad, Telangana', 'Staff'],
    ['Rohan Verma', 'rohan@coldchain.in', 'Customer@123', '+91 98765 10001', 'ColdChain Logistics', 'Plot 14, Medchal Industrial Area, Telangana', 'Customer'],
    ['Sneha Reddy', 'sneha@greenfarms.in', 'Customer@123', '+91 98765 10002', 'GreenFarms Agritech', 'Survey 22, Shamirpet, Telangana', 'Customer'],
    ['Imran Sheikh', 'imran@pharmalabs.in', 'Customer@123', '+91 98765 10003', 'PharmaLabs Pvt Ltd', 'Genome Valley, Hyderabad', 'Customer'],
  ];
  const ids = {};
  for (const u of users) { const [r] = await pool.query('INSERT INTO users (full_name,email,password_hash,phone,company,address,role) VALUES (?,?,?,?,?,?,?)', [u[0], u[1], hash(u[2]), u[3], u[4], u[5], u[6]]); ids[u[1]] = r.insertId; }

  const products = [
    ['TempLog Lite', 'TL-100', 'Temperature', 1, '-40 to 85 °C', 'USB', 120, 2499, null, 'Single-channel USB temperature logger for cold storage and transport. Stores 32,000 readings.'],
    ['TempLog Pro Wi-Fi', 'TL-210W', 'Temperature', 2, '-40 to 125 °C', 'Wi-Fi', 60, 6999, 6299, 'Dual-channel Wi-Fi logger with cloud sync, alarms and 1-second sampling.'],
    ['HumiTrack BLE', 'HT-150B', 'Temperature & Humidity', 2, '-20 to 60 °C, 0-100 %RH', 'Bluetooth', 8, 3899, null, 'Pocket-sized Bluetooth logger for warehouses and labs with phone app access.'],
    ['IndusLog 8CH', 'IL-800E', 'Multi-channel Analog', 8, '0-10 V, 4-20 mA', 'Ethernet', 25, 38500, 36500, 'Eight-channel industrial logger with Modbus TCP, SD backup and DIN-rail mount.'],
    ['AgriSense Cellular', 'AS-320C', 'Soil & Weather', 4, 'Soil moisture, 0-100 %; Air -30 to 70 °C', 'Cellular', 14, 21900, null, '4G field logger with solar input for farms and remote sites.'],
    ['PressureLog PX', 'PL-450U', 'Pressure', 1, '0-10 bar', 'USB', 0, 11800, null, 'High-accuracy USB pressure logger for pipelines and process monitoring.'],
    ['ColdChain Tracker 4G', 'CT-600C', 'Temperature & Shock', 3, '-30 to 70 °C, 0-16 g', 'Cellular', 40, 9450, 8750, 'Real-time shipment tracker with GPS, temperature and shock sensing.'],
    ['EnergyLog 3-Phase', 'EL-920E', 'Power & Energy', 12, '0-600 V, 0-100 A (CT)', 'Ethernet', 5, 52900, null, 'Three-phase power quality logger with 12 channels and harmonic analysis.'],
  ];
  const up = path.join(__dirname, '../uploads'); fs.mkdirSync(up, { recursive: true });
  const pid = [];
  for (let i = 0; i < products.length; i++) {
    const p = products[i]; const file = `demo-${p[1].toLowerCase()}.svg`; fs.writeFileSync(path.join(up, file), svg(p[1], p[2], i));
    const [r] = await pool.query('INSERT INTO data_loggers (name,model_number,image_url,description,logger_type,channels,measurement_range,connectivity,stock_quantity,unit_price,discount_price,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [p[0], p[1], '/uploads/' + file, p[9], p[2], p[3], p[4], p[5], p[6], p[7], p[8], 'Active']);
    pid.push(r.insertId);
    if (p[6]) await pool.query("INSERT INTO inventory_transactions (data_logger_id,change_qty,balance_after,type,note,created_by) VALUES (?,?,?,'Initial','Initial stock',?)", [r.insertId, p[6], p[6], ids['admin@iotlogger.com']]);
  }

  const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const mk = async (email, name, items, status, monthsAgo) => {
    const cu = users.find((u) => u[1] === email);
    const b = await bookingService.create(ids[email], { delivery_name: name, delivery_phone: cu[3], delivery_address: cu[5], booking_date: tomorrow, special_instructions: 'Please include calibration certificates.', items: items.map(([i, q]) => ({ data_logger_id: pid[i], quantity: q })) });
    if (status === 'Pending') return;
    await pool.query("UPDATE bookings SET status='Confirmed' WHERE id=?", [b.id]);
    if (status === 'Confirmed') return;
    const o = await withTx((c) => orderService.createFromBooking(b.id, ids['staff@iotlogger.com'], c));
    const when = new Date(); when.setMonth(when.getMonth() - monthsAgo); when.setDate(10);
    const ts = when.toISOString().slice(0, 19).replace('T', ' ');
    await pool.query('UPDATE orders SET created_at=? WHERE id=?', [ts, o.id]); await pool.query('UPDATE bookings SET created_at=? WHERE id=?', [ts, b.id]);
    await pool.query('UPDATE order_history SET created_at=? WHERE order_id=?', [ts, o.id]);
    if (status === 'Completed') { await orderService.updateStatus(o.id, 'Processing', 'Packed', ids['staff@iotlogger.com']); await orderService.updateStatus(o.id, 'Completed', 'Delivered', ids['staff@iotlogger.com']); await pool.query("UPDATE orders SET payment_status='Paid' WHERE id=?", [o.id]); await pool.query("INSERT INTO payments (order_id,amount,method,status,reference) SELECT id, grand_total, 'Bank Transfer','Completed','UTR-DEMO' FROM orders WHERE id=?", [o.id]); }
    if (status === 'Shipped') await orderService.updateStatus(o.id, 'Shipped', 'Dispatched', ids['staff@iotlogger.com']);
  };
  await mk('rohan@coldchain.in', 'Rohan Verma', [[0, 20], [6, 5]], 'Completed', 4);
  await mk('sneha@greenfarms.in', 'Sneha Reddy', [[4, 3]], 'Completed', 3);
  await mk('imran@pharmalabs.in', 'Imran Sheikh', [[1, 10], [2, 2]], 'Completed', 2);
  await mk('rohan@coldchain.in', 'Rohan Verma', [[3, 2]], 'Shipped', 1);
  await mk('imran@pharmalabs.in', 'Imran Sheikh', [[7, 1]], 'Processing', 0);
  await mk('sneha@greenfarms.in', 'Sneha Reddy', [[0, 15]], 'Confirmed', 0);
  await mk('rohan@coldchain.in', 'Rohan Verma', [[1, 4]], 'Pending', 0);

  const day = (d) => new Date(Date.now() + d * 864e5).toISOString().slice(0, 10);
  const calls = [
    ['rohan@coldchain.in', 'Rohan Verma', 'Quote for 50 additional TL-100 loggers', 'Follow-up Required', 'Asked for bulk discount. Send revised quote.', day(2)],
    ['sneha@greenfarms.in', 'Sneha Reddy', 'Delivery schedule for AgriSense units', 'Completed', 'Confirmed delivery to Shamirpet site.', null],
    ['imran@pharmalabs.in', 'Imran Sheikh', 'Calibration certificate query', 'Scheduled', null, day(1)],
  ];
  for (const c of calls) await pool.query('INSERT INTO call_records (customer_id,customer_name,phone,call_datetime,purpose,status,notes,next_followup,assigned_staff_id,created_by) VALUES (?,?,?,NOW(),?,?,?,?,?,?)',
    [ids[c[0]], c[1], users.find((u) => u[1] === c[0])[3], c[2], c[3], c[4], c[5], ids['staff@iotlogger.com'], ids['staff@iotlogger.com']]);
  console.log('Demo data loaded.\n  Admin:    admin@iotlogger.com / Admin@123\n  Staff:    staff@iotlogger.com / Staff@123\n  Customer: rohan@coldchain.in / Customer@123');
  await pool.end();
})().catch((e) => { console.error('Setup failed:', e.message); process.exit(1); });
