const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const { AppError, asyncHandler } = require('../utils/helpers');

const authenticate = asyncHandler(async (req, res, next) => {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) throw new AppError(401, 'Authentication required');
  let payload;
  try { payload = jwt.verify(h.slice(7), process.env.JWT_SECRET); } catch { throw new AppError(401, 'Invalid or expired token'); }
  const [[u]] = await pool.query('SELECT id, full_name, email, role, is_active FROM users WHERE id=?', [payload.id]);
  if (!u || !u.is_active) throw new AppError(401, 'Account not found or deactivated');
  req.user = u; next();
});
const authorize = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : next(new AppError(403, 'You do not have permission to do this'));
const signToken = (u) => jwt.sign({ id: u.id, role: u.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });
module.exports = { authenticate, authorize, signToken };
// Attaches req.user when a valid token is present but never rejects (used for public catalogue).
module.exports.optionalAuth = async (req, res, next) => {
  try {
    const h = req.headers.authorization || '';
    if (h.startsWith('Bearer ')) {
      const p = jwt.verify(h.slice(7), process.env.JWT_SECRET);
      const [[u]] = await pool.query('SELECT id, full_name, email, role, is_active FROM users WHERE id=?', [p.id]);
      if (u && u.is_active) req.user = u;
    }
  } catch { /* ignore */ }
  next();
};
