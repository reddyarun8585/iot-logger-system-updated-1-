const multer = require('multer');
exports.notFound = (req, res) => res.status(404).json({ message: `Route ${req.method} ${req.originalUrl} not found` });
exports.errorHandler = (err, req, res, next) => {
  let status = err.status || 500, message = err.message, details = err.details;
  if (err instanceof multer.MulterError) { status = 422; message = err.code === 'LIMIT_FILE_SIZE' ? 'Image must be 2 MB or smaller' : err.message; }
  if (err.code === 'ER_DUP_ENTRY') { status = 409; message = 'A record with this value already exists'; }
  if (status >= 500) { console.error('[error]', err.code || err.message); message = 'Something went wrong on the server'; }
  res.status(status).json({ message, details });
};
