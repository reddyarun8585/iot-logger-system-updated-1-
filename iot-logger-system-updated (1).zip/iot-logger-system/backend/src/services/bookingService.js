const { withTx } = require('../config/db');
const { AppError, validate, clean, code } = require('../utils/helpers');

const effective = (i) => (i.discount_price != null && Number(i.discount_price) > 0 ? Number(i.discount_price) : Number(i.unit_price));

async function create(userId, b) {
  validate(b, {
    delivery_name: { required: true, label: 'Contact name' },
    delivery_phone: { required: true, type: 'phone', label: 'Phone' },
    delivery_address: { required: true, minLen: 5, label: 'Delivery address' },
    booking_date: { required: true, type: 'date', label: 'Booking date' },
  });
  if (new Date(b.booking_date) < new Date(new Date().toDateString())) throw new AppError(422, 'Booking date cannot be in the past', { booking_date: 'Choose today or a later date' });
  if (!Array.isArray(b.items) || !b.items.length) throw new AppError(422, 'Add at least one product', { items: 'Add at least one product' });
  const merged = {};
  for (const it of b.items) {
    const q = Number(it.quantity), id = Number(it.data_logger_id);
    if (!Number.isInteger(q) || q < 1 || q > 10000) throw new AppError(422, 'Quantity must be a whole number of 1 or more', { items: 'Invalid quantity' });
    merged[id] = (merged[id] || 0) + q;
  }
  return withTx(async (c) => {
    let total = 0; const lines = [];
    for (const [id, qty] of Object.entries(merged)) {
      const [[p]] = await c.query('SELECT * FROM data_loggers WHERE id=?', [id]);
      if (!p || p.status !== 'Active') throw new AppError(422, 'A selected product is not available');
      if (p.stock_quantity < qty) throw new AppError(409, `Only ${p.stock_quantity} unit(s) of ${p.name} are in stock`);
      total += effective(p) * qty; lines.push([p, qty]);
    }
    const [r] = await c.query(
      'INSERT INTO bookings (booking_code,user_id,booking_date,delivery_name,delivery_phone,delivery_address,special_instructions,total_amount) VALUES (?,?,?,?,?,?,?,?)',
      ['TMP-' + Date.now() + Math.random(), userId, b.booking_date, clean(b.delivery_name), clean(b.delivery_phone), clean(b.delivery_address), clean(b.special_instructions) || null, total.toFixed(2)]);
    const bookingCode = code('BK', r.insertId);
    await c.query('UPDATE bookings SET booking_code=? WHERE id=?', [bookingCode, r.insertId]);
    for (const [p, qty] of lines)
      await c.query('INSERT INTO booking_items (booking_id,data_logger_id,quantity,unit_price,discount_price) VALUES (?,?,?,?,?)', [r.insertId, p.id, qty, p.unit_price, p.discount_price]);
    return { id: r.insertId, booking_code: bookingCode };
  });
}
module.exports = { create, effective };
