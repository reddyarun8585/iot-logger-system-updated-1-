const { withTx } = require('../config/db');
const { AppError, code, getSettings } = require('../utils/helpers');
const { effective } = require('./bookingService');

const TERMINAL = ['Completed', 'Cancelled'];
const FLOW = ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Completed'];

/** Creates an order from a Confirmed booking. Stock rows are locked so concurrent orders cannot oversell. */
function createFromBooking(bookingId, actorId, c0) {
  const run = async (c) => {
    const [[b]] = await c.query('SELECT * FROM bookings WHERE id=? FOR UPDATE', [bookingId]);
    if (!b) throw new AppError(404, 'Booking not found');
    if (b.status !== 'Confirmed') throw new AppError(400, 'Only confirmed bookings can be converted into orders');
    const [dup] = await c.query('SELECT id FROM orders WHERE booking_id=?', [bookingId]);
    if (dup.length) throw new AppError(409, 'An order already exists for this booking');
    const [items] = await c.query(
      'SELECT bi.*, d.name, d.model_number, d.image_url FROM booking_items bi JOIN data_loggers d ON d.id=bi.data_logger_id WHERE bi.booking_id=? ORDER BY bi.data_logger_id', [bookingId]);
    const s = await getSettings(c);
    let subtotal = 0, net = 0;
    for (const i of items) { subtotal += Number(i.unit_price) * i.quantity; net += effective(i) * i.quantity; }
    const discount = subtotal - net, tax = +(net * Number(s.tax_rate) / 100).toFixed(2), shipping = Number(s.shipping_flat);
    const grand = +(net + tax + shipping).toFixed(2);
    const [o] = await c.query(
      'INSERT INTO orders (order_number,booking_id,user_id,status,subtotal,discount_total,tax_amount,shipping_amount,grand_total,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)',
      ['TMP-' + Date.now() + Math.random(), bookingId, b.user_id, 'Confirmed', subtotal.toFixed(2), discount.toFixed(2), tax, shipping, grand, actorId]);
    const orderNumber = code('ORD', o.insertId);
    await c.query('UPDATE orders SET order_number=? WHERE id=?', [orderNumber, o.insertId]);
    for (const i of items) {
      // Lock the product row, then decrement only if enough stock remains.
      const [[p]] = await c.query('SELECT stock_quantity FROM data_loggers WHERE id=? FOR UPDATE', [i.data_logger_id]);
      if (p.stock_quantity < i.quantity) throw new AppError(409, `Insufficient stock for ${i.name} (available ${p.stock_quantity}, needed ${i.quantity})`);
      await c.query('UPDATE data_loggers SET stock_quantity=stock_quantity-? WHERE id=?', [i.quantity, i.data_logger_id]);
      await c.query('INSERT INTO inventory_transactions (data_logger_id,change_qty,balance_after,type,reference,created_by) VALUES (?,?,?,?,?,?)',
        [i.data_logger_id, -i.quantity, p.stock_quantity - i.quantity, 'Sale', orderNumber, actorId]);
      await c.query('INSERT INTO order_items (order_id,data_logger_id,product_name,model_number,image_url,quantity,unit_price,discount_price,line_total) VALUES (?,?,?,?,?,?,?,?,?)',
        [o.insertId, i.data_logger_id, i.name, i.model_number, i.image_url, i.quantity, i.unit_price, i.discount_price, (effective(i) * i.quantity).toFixed(2)]);
    }
    await c.query("UPDATE bookings SET status='Processing' WHERE id=?", [bookingId]);
    await c.query('INSERT INTO order_history (order_id,status,note,changed_by) VALUES (?,?,?,?)', [o.insertId, 'Confirmed', 'Order created from booking ' + b.booking_code, actorId]);
    return { id: o.insertId, order_number: orderNumber };
  };
  return c0 ? run(c0) : withTx(run);
}

async function updateStatus(orderId, status, note, actorId) {
  return withTx(async (c) => {
    const [[o]] = await c.query('SELECT * FROM orders WHERE id=? FOR UPDATE', [orderId]);
    if (!o) throw new AppError(404, 'Order not found');
    if (TERMINAL.includes(o.status)) throw new AppError(400, `A ${o.status.toLowerCase()} order can no longer be changed`);
    if (!FLOW.includes(status) && status !== 'Cancelled') throw new AppError(422, 'Invalid status');
    if (status === 'Cancelled') {
      const [items] = await c.query('SELECT * FROM order_items WHERE order_id=? ORDER BY data_logger_id', [orderId]);
      for (const i of items) {
        const [[p]] = await c.query('SELECT stock_quantity FROM data_loggers WHERE id=? FOR UPDATE', [i.data_logger_id]);
        await c.query('UPDATE data_loggers SET stock_quantity=stock_quantity+? WHERE id=?', [i.quantity, i.data_logger_id]);
        await c.query('INSERT INTO inventory_transactions (data_logger_id,change_qty,balance_after,type,reference,created_by) VALUES (?,?,?,?,?,?)',
          [i.data_logger_id, i.quantity, p.stock_quantity + i.quantity, 'Cancellation', o.order_number, actorId]);
      }
    }
    await c.query('UPDATE orders SET status=? WHERE id=?', [status, orderId]);
    await c.query('INSERT INTO order_history (order_id,status,note,changed_by) VALUES (?,?,?,?)', [orderId, status, note || null, actorId]);
    if (o.booking_id) {
      const bs = status === 'Cancelled' ? 'Cancelled' : status === 'Completed' ? 'Completed' : 'Processing';
      await c.query('UPDATE bookings SET status=? WHERE id=?', [bs, o.booking_id]);
    }
    return { id: orderId, status };
  });
}
module.exports = { createFromBooking, updateStatus };
