require('dotenv').config();
const express = require('express'), cors = require('cors'), helmet = require('helmet'), path = require('path');
const { pool } = require('./config/db');
const { notFound, errorHandler } = require('./middleware/error');
const { asyncHandler } = require('./utils/helpers');

// Never let one bad request or DB hiccup kill the server.
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e && e.message ? e.message : e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e && e.message ? e.message : e));

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 16) {
  console.error('\nJWT_SECRET missing or too short.\n  1) In the backend folder run:  copy .env.example .env   (Mac/Linux: cp .env.example .env)\n  2) Open .env and set DB_PASSWORD and a JWT_SECRET of at least 16 characters.\n');
  process.exit(1);
}

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
const origins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map((s) => s.trim());
// also allow 127.0.0.1 variant of localhost in development
if (process.env.NODE_ENV !== 'production') origins.push('http://127.0.0.1:5173');
app.use(cors({ origin: origins, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads'), { maxAge: '7d' }));
app.get('/', (req, res) => res.json({ name: 'IoT Logger API', status: 'running', health: '/api/health' }));
app.get('/api/health', asyncHandler(async (req, res) => { await pool.query('SELECT 1'); res.json({ status: 'ok' }); }));
app.use('/api', require('./routes'));
app.use(notFound);
app.use(errorHandler);

async function start() {
  try {
    await pool.query('SELECT 1');
    const [t] = await pool.query("SHOW TABLES LIKE 'users'");
    if (!t.length) console.warn('\n[warn] Database is reachable but tables are missing. Run:  npm run db:setup\n');
  } catch (e) {
    const hint = {
      ECONNREFUSED: 'MySQL is not running. Start the MySQL service, then try again.',
      ER_ACCESS_DENIED_ERROR: 'Wrong DB_USER / DB_PASSWORD in backend/.env.',
      ER_BAD_DB_ERROR: `Database "${process.env.DB_NAME}" does not exist. Run:  npm run db:setup`,
      ENOTFOUND: 'DB_HOST in backend/.env is wrong.',
    }[e.code] || e.message;
    console.error(`\n[db] Cannot connect to MySQL (${e.code || 'error'}): ${hint}\n`);
    process.exit(1);
  }
  const port = process.env.PORT || 5000;
  const server = app.listen(port, () => console.log(`API running on http://localhost:${port}`));
  server.on('error', (e) => {
    console.error(e.code === 'EADDRINUSE' ? `\nPort ${port} is already in use. Close the other server or change PORT in backend/.env.\n` : e.message);
    process.exit(1);
  });
  const stop = () => server.close(() => pool.end().finally(() => process.exit(0)));
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
start();
