const router = require('express').Router();
const { authenticate, authorize, optionalAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const A = require('../controllers/authController'), U = require('../controllers/userController'), P = require('../controllers/productController'),
  B = require('../controllers/bookingController'), O = require('../controllers/orderController'), C = require('../controllers/callController'),
  I = require('../controllers/inventoryController'), R = require('../controllers/reportController');
const admin = authorize('Admin'), staff = authorize('Admin', 'Staff');

// in-memory throttle (per IP): 10 FAILED attempts / 15 min. Successful requests do not count.
const hits = new Map();
const throttle = (req, res, next) => {
  const k = req.ip, now = Date.now(); const arr = (hits.get(k) || []).filter((t) => now - t < 900000);
  if (arr.length >= 10) return res.status(429).json({ message: 'Too many failed attempts. Try again in a few minutes.' });
  res.on('finish', () => { if (res.statusCode >= 400) { const a = (hits.get(k) || []).filter((t) => Date.now() - t < 900000); a.push(Date.now()); hits.set(k, a); } });
  next();
};
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some((t) => now - t < 900000)) hits.delete(k); }, 600000).unref();

router.post('/auth/register', throttle, A.register);
router.post('/auth/login', throttle, A.login);
router.get('/auth/me', authenticate, A.me);
router.put('/auth/profile', authenticate, A.updateProfile);
router.put('/auth/password', authenticate, A.changePassword);

router.get('/users', authenticate, staff, U.list);
router.post('/users', authenticate, admin, U.create);
router.get('/users/:id', authenticate, staff, U.get);
router.put('/users/:id', authenticate, admin, U.update);
router.patch('/users/:id/status', authenticate, admin, U.setStatus);

router.get('/products', optionalAuth, P.list);
router.get('/products/:id', optionalAuth, P.get);
router.post('/products', authenticate, admin, upload.single('image'), P.create);
router.put('/products/:id', authenticate, admin, upload.single('image'), P.update);
router.delete('/products/:id', authenticate, admin, P.remove);

router.post('/bookings', authenticate, B.create);
router.get('/bookings', authenticate, B.list);
router.get('/bookings/:id', authenticate, B.get);
router.patch('/bookings/:id/status', authenticate, B.setStatus);
router.post('/bookings/:id/order', authenticate, staff, B.createOrder);

router.get('/orders', authenticate, O.list);
router.get('/orders/:id', authenticate, O.get);
router.patch('/orders/:id/status', authenticate, staff, O.setStatus);
router.patch('/orders/:id/payment', authenticate, staff, O.setPayment);

router.get('/calls', authenticate, staff, C.list);
router.post('/calls', authenticate, staff, C.create);
router.get('/calls/:id', authenticate, staff, C.get);
router.put('/calls/:id', authenticate, staff, C.update);
router.delete('/calls/:id', authenticate, admin, C.remove);

router.get('/inventory/summary', authenticate, staff, I.summary);
router.get('/inventory/transactions', authenticate, staff, I.transactions);
router.patch('/inventory/:id', authenticate, admin, I.update);

router.get('/reports/dashboard', authenticate, staff, R.dashboard);
router.get('/reports/summary', authenticate, staff, R.reports);
router.get('/notifications', authenticate, staff, R.notifications);
router.get('/settings', authenticate, R.getSettings);
router.put('/settings', authenticate, admin, R.saveSettings);

module.exports = router;
