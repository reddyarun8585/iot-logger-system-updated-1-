const { pool } = require('../config/db');
const { asyncHandler, getSettings } = require('../utils/helpers');

exports.dashboard = asyncHandler(async (req, res) => {
  const q = async (sql, p) => (await pool.query(sql, p))[0];
  const [[loggers], [users], [bookings], [orders]] = await Promise.all([
    q("SELECT COUNT(*) n FROM data_loggers WHERE status<>'Discontinued'"), q('SELECT COUNT(*) n FROM users'), q('SELECT COUNT(*) n FROM bookings'),
    q(`SELECT COUNT(*) total, SUM(status IN ('Pending','Confirmed','Processing','Shipped')) pending, SUM(status='Completed') completed,
       COALESCE(SUM(CASE WHEN status<>'Cancelled' THEN grand_total END),0) revenue FROM orders`)]);
  const recentBookings = await q('SELECT b.id, b.booking_code, b.status, b.total_amount, b.created_at, u.full_name customer_name FROM bookings b JOIN users u ON u.id=b.user_id ORDER BY b.created_at DESC LIMIT 5');
  const recentOrders = await q('SELECT o.id, o.order_number, o.status, o.grand_total, o.created_at, u.full_name customer_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 5');
  const salesByLogger = await q(`SELECT oi.model_number name, SUM(oi.quantity) units, SUM(oi.line_total) sales FROM order_items oi JOIN orders o ON o.id=oi.order_id
    WHERE o.status<>'Cancelled' GROUP BY oi.model_number ORDER BY units DESC LIMIT 8`);
  const monthlyRevenue = await q(`SELECT DATE_FORMAT(created_at,'%Y-%m') month, SUM(grand_total) revenue, COUNT(*) orders FROM orders
    WHERE status<>'Cancelled' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 11 MONTH) GROUP BY month ORDER BY month`);
  res.json({ totals: { loggers: loggers.n, users: users.n, bookings: bookings.n, orders: orders.total, pending_orders: Number(orders.pending || 0), completed_orders: Number(orders.completed || 0), revenue: orders.revenue },
    recentBookings, recentOrders, salesByLogger, monthlyRevenue });
});

exports.reports = asyncHandler(async (req, res) => {
  const w = ["o.status<>'Cancelled'"]; const p = [];
  if (req.query.from) { w.push('DATE(o.created_at)>=?'); p.push(req.query.from); }
  if (req.query.to) { w.push('DATE(o.created_at)<=?'); p.push(req.query.to); }
  const where = 'WHERE ' + w.join(' AND ');
  const q = async (sql, params = []) => (await pool.query(sql, params))[0];
  const [[tot]] = [await q(`SELECT COUNT(*) orders, COALESCE(SUM(grand_total),0) revenue, COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(discount_total),0) discounts, COALESCE(AVG(grand_total),0) avg_order FROM orders o ${where}`, p)];
  res.json({ totals: tot,
    byStatus: await q('SELECT status, COUNT(*) count FROM orders GROUP BY status'),
    byProduct: await q(`SELECT oi.product_name, oi.model_number, SUM(oi.quantity) units, SUM(oi.line_total) sales FROM order_items oi JOIN orders o ON o.id=oi.order_id ${where} GROUP BY oi.data_logger_id, oi.product_name, oi.model_number ORDER BY sales DESC`, p),
    topCustomers: await q(`SELECT u.id, u.full_name, u.company, COUNT(*) orders, SUM(o.grand_total) spent FROM orders o JOIN users u ON u.id=o.user_id ${where} GROUP BY u.id, u.full_name, u.company ORDER BY spent DESC LIMIT 10`, p),
    callsByStatus: await q('SELECT status, COUNT(*) count FROM call_records GROUP BY status'),
    monthly: await q(`SELECT DATE_FORMAT(o.created_at,'%Y-%m') month, COUNT(*) orders, SUM(o.grand_total) revenue FROM orders o ${where} GROUP BY month ORDER BY month`, p) });
});

exports.notifications = asyncHandler(async (req, res) => {
  const th = Number((await getSettings(pool)).low_stock_threshold);
  const [[a]] = await pool.query("SELECT COUNT(*) n FROM bookings WHERE status='Pending'");
  const [[b]] = await pool.query('SELECT COUNT(*) n FROM data_loggers WHERE stock_quantity<=? AND status=\'Active\'', [th]);
  const [[c]] = await pool.query("SELECT COUNT(*) n FROM call_records WHERE status='Follow-up Required' OR (next_followup IS NOT NULL AND next_followup<=CURDATE() AND status<>'Completed')");
  const items = [];
  if (a.n) items.push({ text: `${a.n} pending booking(s) need review`, to: '/bookings?status=Pending' });
  if (b.n) items.push({ text: `${b.n} product(s) low or out of stock`, to: '/inventory' });
  if (c.n) items.push({ text: `${c.n} call follow-up(s) due`, to: '/calls?status=Follow-up Required' });
  res.json({ count: items.length, items });
});

exports.getSettings = asyncHandler(async (req, res) => res.json(await getSettings(pool)));
exports.saveSettings = asyncHandler(async (req, res) => {
  const allowed = ['tax_rate', 'shipping_flat', 'low_stock_threshold', 'company_name'];
  for (const k of allowed) if (req.body[k] !== undefined) {
    if (k !== 'company_name' && (isNaN(Number(req.body[k])) || Number(req.body[k]) < 0)) return res.status(422).json({ message: `${k} must be a non-negative number`, details: { [k]: 'Enter a non-negative number' } });
    await pool.query('INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)', [k, String(req.body[k]).slice(0, 255)]);
  }
  res.json(await getSettings(pool));
});
