const { pool } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult, validate } = require('../utils/helpers');
const orderService = require('../services/orderService');
const isStaff = (u) => ['Admin', 'Staff'].includes(u.role);

exports.list = asyncHandler(async (req, res) => {
  const pg = paginate(req); const w = []; const p = [];
  if (!isStaff(req.user)) { w.push('o.user_id=?'); p.push(req.user.id); }
  if (req.query.status) { w.push('o.status=?'); p.push(req.query.status); }
  if (req.query.payment_status) { w.push('o.payment_status=?'); p.push(req.query.payment_status); }
  if (req.query.search) { w.push('(o.order_number LIKE ? OR u.full_name LIKE ?)'); p.push(`%${req.query.search}%`, `%${req.query.search}%`); }
  if (req.query.from) { w.push('DATE(o.created_at)>=?'); p.push(req.query.from); }
  if (req.query.to) { w.push('DATE(o.created_at)<=?'); p.push(req.query.to); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n FROM orders o JOIN users u ON u.id=o.user_id ${where}`, p);
  const [rows] = await pool.query(`SELECT o.*, u.full_name customer_name FROM orders o JOIN users u ON u.id=o.user_id ${where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

exports.get = asyncHandler(async (req, res) => {
  const [[o]] = await pool.query(`SELECT o.*, u.full_name customer_name, u.email customer_email, u.phone customer_phone, b.booking_code,
    b.delivery_name, b.delivery_phone, b.delivery_address, b.special_instructions
    FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN bookings b ON b.id=o.booking_id WHERE o.id=?`, [req.params.id]);
  if (!o || (!isStaff(req.user) && o.user_id !== req.user.id)) throw new AppError(404, 'Order not found');
  const [items] = await pool.query('SELECT * FROM order_items WHERE order_id=?', [o.id]);
  const [history] = await pool.query('SELECT h.*, u.full_name changed_by_name FROM order_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.order_id=? ORDER BY h.id', [o.id]);
  const [payments] = await pool.query('SELECT * FROM payments WHERE order_id=? ORDER BY id', [o.id]);
  res.json({ ...o, items, history, payments });
});

exports.setStatus = asyncHandler(async (req, res) => {
  validate(req.body, { status: { required: true, in: ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Completed', 'Cancelled'] } });
  res.json(await orderService.updateStatus(Number(req.params.id), req.body.status, req.body.note, req.user.id));
});

// Payment tracking only. No card data is accepted or stored; a gateway can be wired in later via credentials in .env.
exports.setPayment = asyncHandler(async (req, res) => {
  validate(req.body, { payment_status: { required: true, in: ['Unpaid', 'Partial', 'Paid', 'Refunded'] }, method: { in: ['Cash', 'Bank Transfer', 'UPI', 'Card', 'Other'] }, amount: { type: 'number', min: 0 } });
  const [[o]] = await pool.query('SELECT * FROM orders WHERE id=?', [req.params.id]);
  if (!o) throw new AppError(404, 'Order not found');
  const { payment_status, method, reference } = req.body;
  const amount = req.body.amount ? Number(req.body.amount) : o.grand_total;
  await pool.query('UPDATE orders SET payment_status=? WHERE id=?', [payment_status, o.id]);
  if (['Paid', 'Partial', 'Refunded'].includes(payment_status))
    await pool.query('INSERT INTO payments (order_id,amount,method,status,reference,created_by) VALUES (?,?,?,?,?,?)',
      [o.id, amount, method || 'Bank Transfer', payment_status === 'Refunded' ? 'Refunded' : 'Completed', (reference || '').slice(0, 100) || null, req.user.id]);
  res.json({ message: 'Payment status updated' });
});
