const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { AppError, asyncHandler, validate, clean } = require('../utils/helpers');
const { signToken } = require('../middleware/auth');

const pwRule = { required: true, minLen: 8, label: 'Password' };
const strongPw = (p) => { if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) throw new AppError(422, 'Password needs letters and numbers', { password: 'Use at least one letter and one number' }); };
const publicUser = 'id, full_name, email, phone, company, address, role, is_active, created_at';

exports.register = asyncHandler(async (req, res) => {
  const b = req.body;
  validate(b, { full_name: { required: true, minLen: 2, label: 'Full name' }, email: { required: true, type: 'email' }, phone: { required: true, type: 'phone' }, password: pwRule });
  strongPw(b.password);
  const [dup] = await pool.query('SELECT id FROM users WHERE email=?', [b.email.trim().toLowerCase()]);
  if (dup.length) throw new AppError(409, 'This email is already registered', { email: 'This email is already registered' });
  const hash = await bcrypt.hash(b.password, 12);
  const [r] = await pool.query('INSERT INTO users (full_name,email,password_hash,phone,company,address,role) VALUES (?,?,?,?,?,?,?)',
    [clean(b.full_name), b.email.trim().toLowerCase(), hash, clean(b.phone), clean(b.company) || null, clean(b.address) || null, 'Customer']);
  const [[u]] = await pool.query(`SELECT ${publicUser} FROM users WHERE id=?`, [r.insertId]);
  res.status(201).json({ token: signToken(u), user: u });
});

exports.login = asyncHandler(async (req, res) => {
  validate(req.body, { email: { required: true, type: 'email' }, password: { required: true } });
  const [[u]] = await pool.query('SELECT * FROM users WHERE email=?', [req.body.email.trim().toLowerCase()]);
  const ok = u && (await bcrypt.compare(req.body.password, u.password_hash));
  if (!ok) throw new AppError(401, 'Incorrect email or password');
  if (!u.is_active) throw new AppError(403, 'This account is deactivated. Contact an administrator.');
  delete u.password_hash;
  res.json({ token: signToken(u), user: u });
});

exports.me = asyncHandler(async (req, res) => {
  const [[u]] = await pool.query(`SELECT ${publicUser} FROM users WHERE id=?`, [req.user.id]);
  res.json(u);
});

exports.updateProfile = asyncHandler(async (req, res) => {
  const b = req.body;
  validate(b, { full_name: { required: true, minLen: 2 }, phone: { required: true, type: 'phone' } });
  await pool.query('UPDATE users SET full_name=?, phone=?, company=?, address=? WHERE id=?', [clean(b.full_name), clean(b.phone), clean(b.company) || null, clean(b.address) || null, req.user.id]);
  const [[u]] = await pool.query(`SELECT ${publicUser} FROM users WHERE id=?`, [req.user.id]);
  res.json(u);
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { current_password, password } = req.body;
  validate(req.body, { current_password: { required: true, label: 'Current password' }, password: pwRule });
  strongPw(password);
  const [[u]] = await pool.query('SELECT password_hash FROM users WHERE id=?', [req.user.id]);
  if (!(await bcrypt.compare(current_password, u.password_hash))) throw new AppError(400, 'Current password is incorrect', { current_password: 'Incorrect password' });
  await pool.query('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(password, 12), req.user.id]);
  res.json({ message: 'Password updated' });
});
