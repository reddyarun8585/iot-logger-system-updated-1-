const bcrypt = require('bcryptjs'); const crypto = require('crypto');
const { pool } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult, validate, clean } = require('../utils/helpers');
const STATUS = ['Scheduled', 'Completed', 'Missed', 'Follow-up Required'];
const SEL = `SELECT c.*, s.full_name staff_name FROM call_records c LEFT JOIN users s ON s.id=c.assigned_staff_id`;

exports.list = asyncHandler(async (req, res) => {
  const pg = paginate(req); const w = []; const p = [];
  if (req.query.search) { w.push('(c.customer_name LIKE ? OR c.phone LIKE ? OR c.purpose LIKE ?)'); const s = `%${req.query.search}%`; p.push(s, s, s); }
  if (req.query.status) { w.push('c.status=?'); p.push(req.query.status); }
  if (req.query.customer_id) { w.push('c.customer_id=?'); p.push(req.query.customer_id); }
  if (req.query.staff_id) { w.push('c.assigned_staff_id=?'); p.push(req.query.staff_id); }
  if (req.query.from) { w.push('DATE(c.call_datetime)>=?'); p.push(req.query.from); }
  if (req.query.to) { w.push('DATE(c.call_datetime)<=?'); p.push(req.query.to); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n FROM call_records c ${where}`, p);
  const [rows] = await pool.query(`${SEL} ${where} ORDER BY c.call_datetime DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

exports.get = asyncHandler(async (req, res) => {
  const [[r]] = await pool.query(`${SEL} WHERE c.id=?`, [req.params.id]);
  if (!r) throw new AppError(404, 'Call record not found');
  res.json(r);
});

async function resolveCustomer(b) {
  if (b.customer_id) {
    const [[u]] = await pool.query('SELECT id, full_name, phone FROM users WHERE id=?', [b.customer_id]);
    if (!u) throw new AppError(422, 'Selected customer not found', { customer_id: 'Customer not found' });
    return { id: u.id, name: u.full_name, phone: b.phone ? clean(b.phone) : u.phone };
  }
  validate(b, { customer_name: { required: true, minLen: 2, label: 'Customer name' }, phone: { required: true, type: 'phone' } });
  // New customer: create a login-capable account only if an email was provided (random password, must be reset by admin).
  if (b.email) {
    validate(b, { email: { type: 'email' } });
    const em = b.email.trim().toLowerCase();
    const [dup] = await pool.query('SELECT id FROM users WHERE email=?', [em]);
    if (dup.length) throw new AppError(409, 'A user with this email already exists. Select them from the list.', { email: 'Email already registered' });
    const [r] = await pool.query("INSERT INTO users (full_name,email,password_hash,phone,role) VALUES (?,?,?,?, 'Customer')", [clean(b.customer_name), em, await bcrypt.hash(crypto.randomBytes(12).toString('hex'), 10), clean(b.phone)]);
    return { id: r.insertId, name: clean(b.customer_name), phone: clean(b.phone) };
  }
  return { id: null, name: clean(b.customer_name), phone: clean(b.phone) };
}
const base = { purpose: { required: true, minLen: 3 }, call_datetime: { required: true, type: 'date', label: 'Call date and time' }, status: { required: true, in: STATUS }, next_followup: { type: 'date' } };

exports.create = asyncHandler(async (req, res) => {
  const b = req.body; validate(b, base); const c = await resolveCustomer(b);
  const [r] = await pool.query('INSERT INTO call_records (customer_id,customer_name,phone,call_datetime,purpose,status,notes,next_followup,assigned_staff_id,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)',
    [c.id, c.name, c.phone, b.call_datetime.replace('T', ' ').slice(0, 19), clean(b.purpose), b.status, clean(b.notes) || null, b.next_followup || null, b.assigned_staff_id || req.user.id, req.user.id]);
  res.status(201).json({ id: r.insertId });
});

exports.update = asyncHandler(async (req, res) => {
  const b = req.body; validate(b, base);
  const c = await resolveCustomer(b.customer_id ? b : { ...b, customer_name: b.customer_name, phone: b.phone });
  const [r] = await pool.query('UPDATE call_records SET customer_id=?,customer_name=?,phone=?,call_datetime=?,purpose=?,status=?,notes=?,next_followup=?,assigned_staff_id=? WHERE id=?',
    [c.id, c.name, c.phone, b.call_datetime.replace('T', ' ').slice(0, 19), clean(b.purpose), b.status, clean(b.notes) || null, b.next_followup || null, b.assigned_staff_id || null, req.params.id]);
  if (!r.affectedRows) throw new AppError(404, 'Call record not found');
  res.json({ message: 'Call record updated' });
});

exports.remove = asyncHandler(async (req, res) => { await pool.query('DELETE FROM call_records WHERE id=?', [req.params.id]); res.json({ message: 'Deleted' }); });
