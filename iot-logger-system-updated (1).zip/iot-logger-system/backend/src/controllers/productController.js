const fs = require('fs'); const path = require('path');
const { pool } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult, validate, clean, getSettings } = require('../utils/helpers');

const SALES = `LEFT JOIN (SELECT oi.data_logger_id id, SUM(oi.quantity) units_sold, SUM(oi.line_total) total_sales
  FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status<>'Cancelled' GROUP BY oi.data_logger_id) s ON s.id=d.id`;
const SELECT = (th) => `SELECT d.*, COALESCE(s.units_sold,0) units_sold, COALESCE(s.total_sales,0) total_sales,
  CASE WHEN d.stock_quantity=0 THEN 'Out of Stock' WHEN d.stock_quantity<=${Number(th)} THEN 'Low Stock' ELSE 'In Stock' END stock_status
  FROM data_loggers d ${SALES}`;
const CONN = ['Wi-Fi', 'Bluetooth', 'USB', 'Ethernet', 'Cellular'];
const rules = {
  name: { required: true, minLen: 2, label: 'Product name' }, model_number: { required: true, label: 'Model number' },
  logger_type: { required: true, label: 'Logger type' }, channels: { required: true, type: 'int', min: 1, max: 256, label: 'Channels' },
  connectivity: { required: true, in: CONN }, stock_quantity: { required: true, type: 'int', min: 0, label: 'Stock' },
  unit_price: { required: true, type: 'number', min: 0.01, label: 'Unit price' }, discount_price: { type: 'number', min: 0, label: 'Discount price' },
  status: { required: true, in: ['Active', 'Inactive', 'Discontinued'] },
};
function check(b) {
  validate(b, rules);
  if (b.discount_price !== '' && b.discount_price != null && Number(b.discount_price) >= Number(b.unit_price))
    throw new AppError(422, 'Discount price must be lower than unit price', { discount_price: 'Must be lower than unit price' });
}
const dp = (b) => (b.discount_price === '' || b.discount_price == null ? null : Number(b.discount_price));

exports.list = asyncHandler(async (req, res) => {
  const pg = paginate(req, 100); const th = (await getSettings(pool)).low_stock_threshold;
  const staff = req.user && ['Admin', 'Staff'].includes(req.user.role);
  const w = []; const p = [];
  if (!staff) w.push("d.status='Active'"); else if (req.query.status) { w.push('d.status=?'); p.push(req.query.status); }
  if (req.query.search) { w.push('(d.name LIKE ? OR d.model_number LIKE ? OR d.logger_type LIKE ?)'); const s = `%${req.query.search}%`; p.push(s, s, s); }
  if (req.query.connectivity) { w.push('d.connectivity=?'); p.push(req.query.connectivity); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n FROM data_loggers d ${where}`, p);
  const [rows] = await pool.query(`${SELECT(th)} ${where} ORDER BY d.created_at DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

exports.get = asyncHandler(async (req, res) => {
  const th = (await getSettings(pool)).low_stock_threshold;
  const [[row]] = await pool.query(`${SELECT(th)} WHERE d.id=?`, [req.params.id]);
  const staff = req.user && ['Admin', 'Staff'].includes(req.user.role);
  if (!row || (!staff && row.status !== 'Active')) throw new AppError(404, 'Product not found');
  res.json(row);
});

exports.create = asyncHandler(async (req, res) => {
  const b = req.body; check(b);
  const img = req.file ? '/uploads/' + req.file.filename : null;
  try {
    const [r] = await pool.query('INSERT INTO data_loggers (name,model_number,image_url,description,logger_type,channels,measurement_range,connectivity,stock_quantity,unit_price,discount_price,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [clean(b.name), clean(b.model_number), img, clean(b.description) || null, clean(b.logger_type), b.channels, clean(b.measurement_range) || null, b.connectivity, b.stock_quantity, b.unit_price, dp(b), b.status]);
    if (Number(b.stock_quantity) > 0) await pool.query("INSERT INTO inventory_transactions (data_logger_id,change_qty,balance_after,type,note,created_by) VALUES (?,?,?,'Initial','Initial stock',?)", [r.insertId, b.stock_quantity, b.stock_quantity, req.user.id]);
    res.status(201).json({ id: r.insertId });
  } catch (e) { if (img) fs.unlink(path.join(__dirname, '../..', img), () => {}); if (e.code === 'ER_DUP_ENTRY') throw new AppError(409, 'This model number already exists', { model_number: 'Model number already exists' }); throw e; }
});

exports.update = asyncHandler(async (req, res) => {
  const b = req.body; check(b);
  const [[old]] = await pool.query('SELECT * FROM data_loggers WHERE id=?', [req.params.id]);
  if (!old) throw new AppError(404, 'Product not found');
  const img = req.file ? '/uploads/' + req.file.filename : old.image_url;
  try {
    await pool.query('UPDATE data_loggers SET name=?,model_number=?,image_url=?,description=?,logger_type=?,channels=?,measurement_range=?,connectivity=?,unit_price=?,discount_price=?,status=? WHERE id=?',
      [clean(b.name), clean(b.model_number), img, clean(b.description) || null, clean(b.logger_type), b.channels, clean(b.measurement_range) || null, b.connectivity, b.unit_price, dp(b), b.status, req.params.id]);
  } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new AppError(409, 'This model number already exists', { model_number: 'Model number already exists' }); throw e; }
  if (req.file && old.image_url && old.image_url.startsWith('/uploads/')) fs.unlink(path.join(__dirname, '../..', old.image_url), () => {});
  res.json({ message: 'Product updated' }); // stock is changed via Inventory so every change is logged
});

exports.remove = asyncHandler(async (req, res) => {
  const [[old]] = await pool.query('SELECT image_url FROM data_loggers WHERE id=?', [req.params.id]);
  if (!old) throw new AppError(404, 'Product not found');
  const { withTx } = require('../config/db');
  try {
    await withTx(async (c) => {
      await c.query('DELETE FROM inventory_transactions WHERE data_logger_id=?', [req.params.id]);
      await c.query('DELETE FROM data_loggers WHERE id=?', [req.params.id]);
    });
  } catch (e) { if (e.code === 'ER_ROW_IS_REFERENCED_2') throw new AppError(409, 'This product has bookings or orders. Set its status to Discontinued instead.'); throw e; }
  if (old.image_url && old.image_url.startsWith('/uploads/')) fs.unlink(path.join(__dirname, '../..', old.image_url), () => {});
  res.json({ message: 'Product deleted' });
});
