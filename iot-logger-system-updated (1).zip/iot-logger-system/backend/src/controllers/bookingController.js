const { pool } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult } = require('../utils/helpers');
const bookingService = require('../services/bookingService');
const orderService = require('../services/orderService');
const isStaff = (u) => ['Admin', 'Staff'].includes(u.role);

exports.create = asyncHandler(async (req, res) => {
  let userId = req.user.id;
  if (isStaff(req.user) && req.body.customer_id) userId = Number(req.body.customer_id);
  res.status(201).json(await bookingService.create(userId, req.body));
});

exports.list = asyncHandler(async (req, res) => {
  const pg = paginate(req); const w = []; const p = [];
  if (!isStaff(req.user)) { w.push('b.user_id=?'); p.push(req.user.id); }
  if (req.query.status) { w.push('b.status=?'); p.push(req.query.status); }
  if (req.query.search) { w.push('(b.booking_code LIKE ? OR u.full_name LIKE ?)'); p.push(`%${req.query.search}%`, `%${req.query.search}%`); }
  if (req.query.from) { w.push('b.booking_date>=?'); p.push(req.query.from); }
  if (req.query.to) { w.push('b.booking_date<=?'); p.push(req.query.to); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const base = `FROM bookings b JOIN users u ON u.id=b.user_id LEFT JOIN orders o ON o.booking_id=b.id ${where}`;
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n ${base}`, p);
  const [rows] = await pool.query(`SELECT b.*, u.full_name customer_name, o.id order_id, o.order_number ${base} ORDER BY b.created_at DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

exports.get = asyncHandler(async (req, res) => {
  const [[b]] = await pool.query(`SELECT b.*, u.full_name customer_name, u.email customer_email, u.phone customer_phone, o.id order_id, o.order_number
    FROM bookings b JOIN users u ON u.id=b.user_id LEFT JOIN orders o ON o.booking_id=b.id WHERE b.id=?`, [req.params.id]);
  if (!b || (!isStaff(req.user) && b.user_id !== req.user.id)) throw new AppError(404, 'Booking not found');
  const [items] = await pool.query(`SELECT bi.*, d.name, d.model_number, d.image_url, d.stock_quantity,
    (CASE WHEN bi.discount_price>0 THEN bi.discount_price ELSE bi.unit_price END)*bi.quantity line_total
    FROM booking_items bi JOIN data_loggers d ON d.id=bi.data_logger_id WHERE bi.booking_id=?`, [b.id]);
  res.json({ ...b, items });
});

exports.setStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const [[b]] = await pool.query('SELECT b.*, o.id order_id FROM bookings b LEFT JOIN orders o ON o.booking_id=b.id WHERE b.id=?', [req.params.id]);
  if (!b) throw new AppError(404, 'Booking not found');
  if (!isStaff(req.user)) {
    if (b.user_id !== req.user.id) throw new AppError(404, 'Booking not found');
    if (status !== 'Cancelled' || b.status !== 'Pending') throw new AppError(403, 'You can only cancel a pending booking');
  }
  if (b.order_id) throw new AppError(400, 'This booking has an order. Update the order status instead.');
  if (!['Pending', 'Confirmed', 'Cancelled'].includes(status)) throw new AppError(422, 'Staff can set Pending, Confirmed or Cancelled. Processing and Completed follow the order.');
  if (b.status === 'Cancelled') throw new AppError(400, 'A cancelled booking cannot be changed');
  await pool.query('UPDATE bookings SET status=? WHERE id=?', [status, b.id]);
  res.json({ message: 'Booking updated' });
});

exports.createOrder = asyncHandler(async (req, res) => res.status(201).json(await orderService.createFromBooking(Number(req.params.id), req.user.id)));
