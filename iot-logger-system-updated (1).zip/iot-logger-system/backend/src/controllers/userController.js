const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult, validate, clean } = require('../utils/helpers');
const cols = 'id, full_name, email, phone, company, address, role, is_active, created_at';

exports.list = asyncHandler(async (req, res) => {
  const pg = paginate(req, 200); const w = []; const p = [];
  if (req.query.search) { w.push('(full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR company LIKE ?)'); const s = `%${req.query.search}%`; p.push(s, s, s, s); }
  if (req.query.role) { w.push('role=?'); p.push(req.query.role); }
  if (req.query.status === 'active') w.push('is_active=1'); else if (req.query.status === 'inactive') w.push('is_active=0');
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n FROM users ${where}`, p);
  const [rows] = await pool.query(`SELECT ${cols} FROM users ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

exports.get = asyncHandler(async (req, res) => {
  const [[u]] = await pool.query(`SELECT ${cols} FROM users WHERE id=?`, [req.params.id]);
  if (!u) throw new AppError(404, 'User not found');
  const [bookings] = await pool.query('SELECT id, booking_code, booking_date, status, total_amount, created_at FROM bookings WHERE user_id=? ORDER BY created_at DESC', [u.id]);
  const [orders] = await pool.query('SELECT id, order_number, status, payment_status, grand_total, created_at FROM orders WHERE user_id=? ORDER BY created_at DESC', [u.id]);
  const [calls] = await pool.query('SELECT id, call_datetime, purpose, status, next_followup FROM call_records WHERE customer_id=? ORDER BY call_datetime DESC', [u.id]);
  res.json({ ...u, bookings, orders, calls });
});

exports.create = asyncHandler(async (req, res) => {
  const b = req.body;
  validate(b, { full_name: { required: true, minLen: 2, label: 'Full name' }, email: { required: true, type: 'email' }, phone: { required: true, type: 'phone' },
    password: { required: true, minLen: 8, label: 'Password' }, role: { required: true, in: ['Admin', 'Staff', 'Customer'] } });
  const [dup] = await pool.query('SELECT id FROM users WHERE email=?', [b.email.trim().toLowerCase()]);
  if (dup.length) throw new AppError(409, 'This email is already registered', { email: 'This email is already registered' });
  const [r] = await pool.query('INSERT INTO users (full_name,email,password_hash,phone,company,address,role) VALUES (?,?,?,?,?,?,?)',
    [clean(b.full_name), b.email.trim().toLowerCase(), await bcrypt.hash(b.password, 12), clean(b.phone), clean(b.company) || null, clean(b.address) || null, b.role]);
  res.status(201).json({ id: r.insertId });
});

exports.update = asyncHandler(async (req, res) => {
  const b = req.body; const id = Number(req.params.id);
  validate(b, { full_name: { required: true, minLen: 2 }, email: { required: true, type: 'email' }, phone: { required: true, type: 'phone' }, role: { required: true, in: ['Admin', 'Staff', 'Customer'] } });
  if (id === req.user.id && b.role !== req.user.role) throw new AppError(400, 'You cannot change your own role');
  const [dup] = await pool.query('SELECT id FROM users WHERE email=? AND id<>?', [b.email.trim().toLowerCase(), id]);
  if (dup.length) throw new AppError(409, 'This email is already registered', { email: 'This email is already registered' });
  const [r] = await pool.query('UPDATE users SET full_name=?,email=?,phone=?,company=?,address=?,role=? WHERE id=?',
    [clean(b.full_name), b.email.trim().toLowerCase(), clean(b.phone), clean(b.company) || null, clean(b.address) || null, b.role, id]);
  if (!r.affectedRows) throw new AppError(404, 'User not found');
  if (b.password) { validate(b, { password: { minLen: 8, label: 'Password' } }); await pool.query('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(b.password, 12), id]); }
  res.json({ message: 'User updated' });
});

exports.setStatus = asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id) throw new AppError(400, 'You cannot deactivate your own account');
  const [r] = await pool.query('UPDATE users SET is_active=? WHERE id=?', [req.body.is_active ? 1 : 0, req.params.id]);
  if (!r.affectedRows) throw new AppError(404, 'User not found');
  res.json({ message: 'Status updated' });
});
