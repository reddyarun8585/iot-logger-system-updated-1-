const { pool, withTx } = require('../config/db');
const { AppError, asyncHandler, paginate, pageResult, validate, clean, getSettings } = require('../utils/helpers');

exports.summary = asyncHandler(async (req, res) => {
  const th = Number((await getSettings(pool)).low_stock_threshold);
  const [[s]] = await pool.query(`SELECT COUNT(*) models, COALESCE(SUM(stock_quantity),0) units,
    SUM(stock_quantity>0 AND stock_quantity<=?) low_stock, SUM(stock_quantity=0) out_of_stock FROM data_loggers WHERE status<>'Discontinued'`, [th]);
  res.json({ ...s, low_stock: Number(s.low_stock || 0), out_of_stock: Number(s.out_of_stock || 0), threshold: th });
});

exports.transactions = asyncHandler(async (req, res) => {
  const pg = paginate(req); const w = []; const p = [];
  if (req.query.product_id) { w.push('t.data_logger_id=?'); p.push(req.query.product_id); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const [[{ n }]] = await pool.query(`SELECT COUNT(*) n FROM inventory_transactions t ${where}`, p);
  const [rows] = await pool.query(`SELECT t.*, d.name, d.model_number, u.full_name user_name FROM inventory_transactions t JOIN data_loggers d ON d.id=t.data_logger_id
    LEFT JOIN users u ON u.id=t.created_by ${where} ORDER BY t.id DESC LIMIT ? OFFSET ?`, [...p, pg.limit, pg.offset]);
  res.json(pageResult(rows, n, pg));
});

// Admin: update price and/or stock. Stock changes are logged; existing orders keep their original prices (snapshotted in order_items).
exports.update = asyncHandler(async (req, res) => {
  const b = req.body;
  validate(b, { unit_price: { type: 'number', min: 0.01, label: 'Unit price' }, discount_price: { type: 'number', min: 0, label: 'Discount price' }, stock_quantity: { type: 'int', min: 0, label: 'Stock' } });
  await withTx(async (c) => {
    const [[p]] = await c.query('SELECT * FROM data_loggers WHERE id=? FOR UPDATE', [req.params.id]);
    if (!p) throw new AppError(404, 'Product not found');
    const unit = b.unit_price !== undefined && b.unit_price !== '' ? Number(b.unit_price) : p.unit_price;
    const disc = b.discount_price === undefined ? p.discount_price : (b.discount_price === '' || b.discount_price === null ? null : Number(b.discount_price));
    if (disc !== null && disc >= unit) throw new AppError(422, 'Discount price must be lower than unit price', { discount_price: 'Must be lower than unit price' });
    await c.query('UPDATE data_loggers SET unit_price=?, discount_price=? WHERE id=?', [unit, disc, p.id]);
    if (b.stock_quantity !== undefined && b.stock_quantity !== '' && Number(b.stock_quantity) !== p.stock_quantity) {
      const q = Number(b.stock_quantity);
      await c.query('UPDATE data_loggers SET stock_quantity=? WHERE id=?', [q, p.id]);
      await c.query('INSERT INTO inventory_transactions (data_logger_id,change_qty,balance_after,type,note,created_by) VALUES (?,?,?,?,?,?)',
        [p.id, q - p.stock_quantity, q, q > p.stock_quantity ? 'Restock' : 'Adjustment', clean(b.note) || 'Manual stock update', req.user.id]);
    }
  });
  res.json({ message: 'Inventory updated' });
});
