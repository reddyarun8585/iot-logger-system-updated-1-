class AppError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
function paginate(req, max = 100) {
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 10, 1), max);
  return { page, limit, offset: (page - 1) * limit };
}
const pageResult = (rows, total, { page, limit }) => ({ data: rows, meta: { page, limit, total, pages: Math.ceil(total / limit) } });
/** rules: { field: { required, type:'email'|'phone'|'number'|'int'|'date', min, max, minLen, in:[...], label } } */
function validate(body, rules) {
  const errors = {};
  for (const [f, r] of Object.entries(rules)) {
    let v = body[f];
    if (typeof v === 'string') v = v.trim();
    const empty = v === undefined || v === null || v === '';
    if (empty) { if (r.required) errors[f] = `${r.label || f} is required`; continue; }
    if (r.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) errors[f] = 'Enter a valid email address';
    else if (r.type === 'phone' && !/^[+\d][\d\s\-()]{6,19}$/.test(v)) errors[f] = 'Enter a valid phone number';
    else if (r.type === 'number' && isNaN(Number(v))) errors[f] = `${r.label || f} must be a number`;
    else if (r.type === 'int' && !Number.isInteger(Number(v))) errors[f] = `${r.label || f} must be a whole number`;
    else if (r.type === 'date' && isNaN(Date.parse(v))) errors[f] = `${r.label || f} must be a valid date`;
    else if (r.in && !r.in.includes(v)) errors[f] = `${r.label || f} must be one of: ${r.in.join(', ')}`;
    else if (r.minLen && String(v).length < r.minLen) errors[f] = `${r.label || f} must be at least ${r.minLen} characters`;
    else if (r.min !== undefined && Number(v) < r.min) errors[f] = `${r.label || f} must be at least ${r.min}`;
    else if (r.max !== undefined && Number(v) > r.max) errors[f] = `${r.label || f} must be at most ${r.max}`;
  }
  if (Object.keys(errors).length) throw new AppError(422, 'Please fix the highlighted fields', errors);
}
const clean = (s) => (typeof s === 'string' ? s.trim().replace(/[<>]/g, '') : s);
const code = (prefix, id) => `${prefix}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(id).padStart(5, '0')}`;
async function getSettings(c) {
  const [rows] = await c.query('SELECT `key`,`value` FROM settings');
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}
module.exports = { AppError, asyncHandler, paginate, pageResult, validate, clean, code, getSettings };
