import axios from 'axios';
const ORIGIN = import.meta.env.VITE_API_ORIGIN || '';
const api = axios.create({ baseURL: ORIGIN + '/api' });
api.interceptors.request.use((cfg) => { const t = localStorage.getItem('token'); if (t) cfg.headers.Authorization = `Bearer ${t}`; return cfg; });
api.interceptors.response.use((r) => r, (e) => {
  const url = e.config?.url || '';
  if (e.response?.status === 401 && !url.includes('/auth/login')) { localStorage.removeItem('token'); localStorage.removeItem('user'); if (!location.pathname.startsWith('/login')) location.href = '/login'; }
  return Promise.reject(e);
});
export const imgUrl = (p) => (p ? ORIGIN + p : '');
export const errMsg = (e) => e.response?.data?.message || (e.request ? 'Cannot reach the server. Check that the backend is running.' : e.message);
export const fieldErrs = (e) => e.response?.data?.details || {};
export default api;
