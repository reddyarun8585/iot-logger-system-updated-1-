import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api';

export const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(n || 0));
export const money2 = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(Number(n || 0));
export const dt = (s) => (s ? new Date(String(s).replace(' ', 'T')).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const d = (s) => (s ? new Date(String(s).slice(0, 10) + 'T00:00:00').toLocaleDateString('en-IN', { dateStyle: 'medium' }) : '—');
export const effPrice = (p) => (Number(p.discount_price) > 0 ? Number(p.discount_price) : Number(p.unit_price));

const TONE = { Pending: 'amber', Confirmed: 'blue', Processing: 'blue', Shipped: 'blue', Completed: 'green', Cancelled: 'red', Paid: 'green', Unpaid: 'amber', Partial: 'amber', Refunded: 'grey',
  Active: 'green', Inactive: 'grey', Discontinued: 'red', 'In Stock': 'green', 'Low Stock': 'amber', 'Out of Stock': 'red', Scheduled: 'blue', Missed: 'red', 'Follow-up Required': 'amber',
  Admin: 'navy', Staff: 'blue', Customer: 'grey' };
export const Badge = ({ children }) => <span className={`badge ${TONE[children] || 'grey'}`}>{children}</span>;

export function useFetch(url, params, deps = []) {
  const [state, set] = useState({ data: null, loading: true, error: null });
  const key = JSON.stringify(params || {});
  const load = useCallback(() => {
    if (!url) return;
    set((s) => ({ ...s, loading: true, error: null }));
    api.get(url, { params }).then((r) => set({ data: r.data, loading: false, error: null })).catch((e) => set({ data: null, loading: false, error: errMsg(e) }));
    // eslint-disable-next-line
  }, [url, key, ...deps]);
  useEffect(load, [load]);
  return { ...state, reload: load };
}

export const Loading = ({ label = 'Loading…' }) => <div className="center-note"><div className="spinner" />{label}</div>;
export const ErrorBox = ({ message, retry }) => <div className="alert error">{message} {retry && <button className="btn sm" onClick={retry}>Try again</button>}</div>;
export const Empty = ({ title, hint, children }) => <div className="empty"><div className="empty-ico">▤</div><strong>{title}</strong>{hint && <p>{hint}</p>}{children}</div>;
export const Async = ({ q, children, empty }) => q.loading ? <Loading /> : q.error ? <ErrorBox message={q.error} retry={q.reload} /> : empty && q.data?.data?.length === 0 ? empty : children(q.data);

export function Pagination({ meta, onPage }) {
  if (!meta || meta.pages <= 1) return meta ? <div className="pager"><span>{meta.total} result{meta.total === 1 ? '' : 's'}</span></div> : null;
  return (
    <div className="pager">
      <span>{meta.total} results · page {meta.page} of {meta.pages}</span>
      <div><button className="btn sm" disabled={meta.page <= 1} onClick={() => onPage(meta.page - 1)}>Previous</button>
        <button className="btn sm" disabled={meta.page >= meta.pages} onClick={() => onPage(meta.page + 1)}>Next</button></div>
    </div>
  );
}
export function Field({ label, error, children, hint }) {
  return <label className={`field ${error ? 'has-error' : ''}`}><span>{label}</span>{children}{hint && !error && <small>{hint}</small>}{error && <em>{error}</em>}</label>;
}
export function Modal({ title, onClose, children, wide }) {
  useEffect(() => { const h = (e) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [onClose]);
  return <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}><div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
    <div className="modal-h"><h3>{title}</h3><button className="icon-btn" onClick={onClose} aria-label="Close">✕</button></div>{children}</div></div>;
}
export function Confirm({ title, message, confirmLabel = 'Confirm', danger, onConfirm, onCancel }) {
  const [busy, setBusy] = useState(false);
  return <Modal title={title} onClose={onCancel}><p>{message}</p><div className="actions">
    <button className="btn" onClick={onCancel}>Keep it</button>
    <button className={`btn ${danger ? 'danger' : 'primary'}`} disabled={busy} onClick={async () => { setBusy(true); try { await onConfirm(); } finally { setBusy(false); } }}>{busy ? 'Working…' : confirmLabel}</button></div></Modal>;
}
export const Stat = ({ label, value, sub, tone }) => <div className={`stat ${tone || ''}`}><span>{label}</span><strong>{value}</strong>{sub && <small>{sub}</small>}</div>;
export const Thumb = ({ src, alt, size = 44 }) => src ? <img className="thumb" style={{ width: size, height: size }} src={src} alt={alt || ''} /> : <div className="thumb ph" style={{ width: size, height: size }}>IoT</div>;
export function PageHead({ title, sub, children }) { return <div className="page-head"><div><h1>{title}</h1>{sub && <p>{sub}</p>}</div><div className="head-actions">{children}</div></div>; }
export function useDebounced(v, ms = 350) { const [x, setX] = useState(v); useEffect(() => { const t = setTimeout(() => setX(v), ms); return () => clearTimeout(t); }, [v, ms]); return x; }
