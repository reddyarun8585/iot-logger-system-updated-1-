import { useState, useEffect } from 'react';
import { NavLink, Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth';
import api from '../api';

const staffNav = [['/', 'Dashboard'], ['/products', 'Data Loggers'], ['/bookings', 'Bookings'], ['/orders', 'Orders'], ['/inventory', 'Inventory & Pricing'], ['/calls', 'Call Members'], ['/users', 'Users'], ['/reports', 'Reports'], ['/settings', 'Settings']];
const custNav = [['/catalogue', 'Product Catalogue'], ['/bookings', 'My Bookings'], ['/orders', 'My Orders'], ['/profile', 'My Profile']];
const guestNav = [['/catalogue', 'Product Catalogue'], ['/login', 'Log in'], ['/register', 'Create account']];

export default function Layout() {
  const { user, isStaff, logout } = useAuth(); const nav = useNavigate(); const loc = useLocation();
  const [open, setOpen] = useState(false); const [menu, setMenu] = useState(null); const [q, setQ] = useState(''); const [notes, setNotes] = useState({ count: 0, items: [] });
  useEffect(() => { setOpen(false); setMenu(null); }, [loc.pathname]);
  useEffect(() => { if (isStaff) api.get('/notifications').then((r) => setNotes(r.data)).catch(() => {}); }, [isStaff, loc.pathname]);
  const links = !user ? guestNav : isStaff ? staffNav : custNav;
  const submit = (e) => { e.preventDefault(); nav(`/catalogue?search=${encodeURIComponent(q)}`); };
  return (
    <div className="shell">
      <aside className={`side ${open ? 'open' : ''}`}>
        <div className="brand"><i>◉</i>SensorLink</div>
        <nav className="nav">
          {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>{label}</NavLink>)}
          {isStaff && <><small>Customer view</small><NavLink to="/catalogue">Product Catalogue</NavLink></>}
        </nav>
      </aside>
      <div className={`scrim ${open ? 'show' : ''}`} onClick={() => setOpen(false)} />
      <div className="main">
        <header className="top">
          <button className="icon-btn burger" onClick={() => setOpen(!open)} aria-label="Open menu">☰</button>
          <form className="search" onSubmit={submit}><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search data loggers by name, model or type" aria-label="Search products" /></form>
          <div className="grow" />
          {isStaff && <div className="menu"><button className="icon-btn" onClick={() => setMenu(menu === 'n' ? null : 'n')} aria-label="Notifications">🔔{notes.count > 0 && <span className="dot">{notes.count}</span>}</button>
            {menu === 'n' && <div className="menu-pop">{notes.items.length ? notes.items.map((n, i) => <Link key={i} to={n.to}>{n.text}</Link>) : <div className="who"><small>You are all caught up.</small></div>}</div>}</div>}
          {user ? <div className="menu"><button className="avatar" onClick={() => setMenu(menu === 'u' ? null : 'u')} aria-label="Account menu">{user.full_name[0]}</button>
            {menu === 'u' && <div className="menu-pop"><div className="who"><strong>{user.full_name}</strong><br /><small>{user.email} · {user.role}</small></div>
              <Link to="/profile">My profile</Link>{isStaff && <Link to="/settings">Settings</Link>}<button onClick={() => { logout(); nav('/login'); }}>Log out</button></div>}</div>
            : <Link className="btn primary" to="/login">Log in</Link>}
        </header>
        <main className="content"><Outlet /></main>
      </div>
    </div>
  );
}
