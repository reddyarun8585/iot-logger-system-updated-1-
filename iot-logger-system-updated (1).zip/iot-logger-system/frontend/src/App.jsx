import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './auth';
import Layout from './components/Layout';
import { Login, Register } from './pages/AuthPages';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import ProductForm from './pages/ProductForm';
import ProductDetails from './pages/ProductDetails';
import BookingForm from './pages/BookingForm';
import { Bookings, BookingDetails } from './pages/Bookings';
import { Orders, OrderDetails } from './pages/Orders';
import Users from './pages/Users';
import CustomerProfile from './pages/CustomerProfile';
import { Calls, CallForm } from './pages/Calls';
import Inventory from './pages/Inventory';
import Reports from './pages/Reports';
import { Profile, Settings } from './pages/Account';
import NotFound from './pages/NotFound';

function Guard({ roles, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}
function Home() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/catalogue" replace />;
  return ['Admin', 'Staff'].includes(user.role) ? <Dashboard /> : <Navigate to="/catalogue" replace />;
}
const S = ['Admin', 'Staff'], A = ['Admin'];
export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/catalogue" element={<Products />} />
        <Route path="/catalogue/:id" element={<ProductDetails />} />
        <Route path="/book/:id" element={<Guard><BookingForm /></Guard>} />
        <Route path="/products" element={<Guard roles={S}><Products manage /></Guard>} />
        <Route path="/products/new" element={<Guard roles={A}><ProductForm /></Guard>} />
        <Route path="/products/:id/edit" element={<Guard roles={A}><ProductForm /></Guard>} />
        <Route path="/bookings" element={<Guard><Bookings /></Guard>} />
        <Route path="/bookings/:id" element={<Guard><BookingDetails /></Guard>} />
        <Route path="/orders" element={<Guard><Orders /></Guard>} />
        <Route path="/orders/:id" element={<Guard><OrderDetails /></Guard>} />
        <Route path="/users" element={<Guard roles={S}><Users /></Guard>} />
        <Route path="/users/:id" element={<Guard roles={S}><CustomerProfile /></Guard>} />
        <Route path="/calls" element={<Guard roles={S}><Calls /></Guard>} />
        <Route path="/calls/new" element={<Guard roles={S}><CallForm /></Guard>} />
        <Route path="/calls/:id/edit" element={<Guard roles={S}><CallForm /></Guard>} />
        <Route path="/inventory" element={<Guard roles={S}><Inventory /></Guard>} />
        <Route path="/reports" element={<Guard roles={S}><Reports /></Guard>} />
        <Route path="/profile" element={<Guard><Profile /></Guard>} />
        <Route path="/settings" element={<Guard roles={S}><Settings /></Guard>} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
