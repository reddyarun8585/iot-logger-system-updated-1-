import { createContext, useContext, useState, useCallback, useRef } from 'react';
import api from './api';
const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } });
  const [toasts, setToasts] = useState([]); const n = useRef(0);
  const toast = useCallback((message, type = 'success') => {
    const id = ++n.current; setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }, []);
  const save = (u, token) => { if (token) localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(u)); setUser(u); };
  const login = async (email, password) => { const { data } = await api.post('/auth/login', { email, password }); save(data.user, data.token); return data.user; };
  const register = async (body) => { const { data } = await api.post('/auth/register', body); save(data.user, data.token); return data.user; };
  const logout = () => { localStorage.removeItem('token'); localStorage.removeItem('user'); setUser(null); };
  const isStaff = user && ['Admin', 'Staff'].includes(user.role);
  return (
    <Ctx.Provider value={{ user, setUser: (u) => save(u), login, register, logout, toast, isStaff, isAdmin: user?.role === 'Admin' }}>
      {children}
      <div className="toasts" role="status" aria-live="polite">{toasts.map((t) => <div key={t.id} className={`toast ${t.type}`}>{t.message}</div>)}</div>
    </Ctx.Provider>
  );
}
