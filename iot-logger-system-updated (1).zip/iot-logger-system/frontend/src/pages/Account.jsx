import { useState } from 'react';
import api, { errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Field, PageHead, Badge } from '../components/ui';

export function Profile() {
  const { user, setUser, toast } = useAuth(); const me = useFetch('/auth/me');
  return <><PageHead title="My profile" sub={`${user.role} account`} /><Async q={me}>{(u) => <ProfileForms u={u} setUser={setUser} toast={toast} />}</Async></>;
}
function ProfileForms({ u, setUser, toast }) {
  const [f, setF] = useState({ full_name: u.full_name, phone: u.phone, company: u.company || '', address: u.address || '' }); const [errs, setErrs] = useState({});
  const [p, setP] = useState({ current_password: '', password: '' }); const [perr, setPerr] = useState({});
  const save = async (e) => { e.preventDefault(); setErrs({}); try { const { data } = await api.put('/auth/profile', f); setUser(data); toast('Profile saved'); } catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } };
  const pw = async (e) => { e.preventDefault(); setPerr({}); try { await api.put('/auth/password', p); setP({ current_password: '', password: '' }); toast('Password changed'); } catch (e2) { setPerr(fieldErrs(e2)); toast(errMsg(e2), 'error'); } };
  return <div className="grid g2"><form className="card" onSubmit={save} noValidate><h2 style={{ marginBottom: 12 }}>Personal details</h2><Field label="Email"><input value={u.email} disabled /></Field>
    <Field label="Full name" error={errs.full_name}><input value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></Field><Field label="Phone" error={errs.phone}><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
    <Field label="Company"><input value={f.company} onChange={(e) => setF({ ...f, company: e.target.value })} /></Field><Field label="Address"><input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field><button className="btn primary">Save profile</button></form>
    <form className="card" onSubmit={pw} noValidate><h2 style={{ marginBottom: 12 }}>Change password</h2><Field label="Current password" error={perr.current_password}><input type="password" value={p.current_password} onChange={(e) => setP({ ...p, current_password: e.target.value })} autoComplete="current-password" /></Field>
      <Field label="New password" error={perr.password} hint="At least 8 characters with a letter and a number"><input type="password" value={p.password} onChange={(e) => setP({ ...p, password: e.target.value })} autoComplete="new-password" /></Field><button className="btn primary">Change password</button></form></div>;
}
export function Settings() {
  const { isAdmin, toast } = useAuth(); const q = useFetch('/settings');
  return <><PageHead title="Settings" sub="Pricing rules and stock alerts used across orders and inventory" />{!isAdmin && <div className="alert info">Only administrators can change settings. Current values are shown below.</div>}
    <Async q={q}>{(s) => <SettingsForm s={s} isAdmin={isAdmin} toast={toast} />}</Async></>;
}
function SettingsForm({ s, isAdmin, toast }) {
  const [f, setF] = useState(s); const [errs, setErrs] = useState({});
  const save = async (e) => { e.preventDefault(); setErrs({}); try { const { data } = await api.put('/settings', f); setF(data); toast('Settings saved'); } catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return <form className="card" onSubmit={save} noValidate style={{ maxWidth: 560 }}><Field label="Company name"><input value={f.company_name} onChange={set('company_name')} disabled={!isAdmin} /></Field>
    <Field label="Tax rate (%)" error={errs.tax_rate} hint="Applied to new orders only"><input type="number" min="0" step="0.01" value={f.tax_rate} onChange={set('tax_rate')} disabled={!isAdmin} /></Field>
    <Field label="Flat shipping charge (₹)" error={errs.shipping_flat} hint="Applied to new orders only"><input type="number" min="0" step="0.01" value={f.shipping_flat} onChange={set('shipping_flat')} disabled={!isAdmin} /></Field>
    <Field label="Low-stock threshold (units)" error={errs.low_stock_threshold}><input type="number" min="0" value={f.low_stock_threshold} onChange={set('low_stock_threshold')} disabled={!isAdmin} /></Field>
    {isAdmin && <button className="btn primary">Save settings</button>}</form>;
}
