import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from 'recharts';
import { useFetch, Async, Stat, PageHead, money, money2 } from '../components/ui';

const COLORS = ['#0b2545', '#1d6fdc', '#5fa8ff', '#16a06b', '#c27b00', '#d6334a'];
export default function Reports() {
  const [from, setFrom] = useState(''); const [to, setTo] = useState('');
  const q = useFetch('/reports/summary', { from: from || undefined, to: to || undefined });
  return <><PageHead title="Reports and analytics" sub="Sales, customers and call activity (cancelled orders excluded from revenue)" />
    <div className="filters"><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" /><input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" /></div>
    <Async q={q}>{(r) => <>
      <div className="stats"><Stat label="Orders" value={r.totals.orders} /><Stat label="Revenue" value={money(r.totals.revenue)} tone="ok" /><Stat label="Average order" value={money(r.totals.avg_order)} /><Stat label="Tax collected" value={money(r.totals.tax)} /><Stat label="Discounts given" value={money(r.totals.discounts)} tone="warn" /></div>
      <div className="grid g2"><div className="card"><h2>Revenue by month</h2><div className="chart-box"><ResponsiveContainer><BarChart data={r.monthly}><CartesianGrid strokeDasharray="3 3" stroke="#e3e9f3" /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} /><Tooltip formatter={(v) => money(v)} /><Bar dataKey="revenue" name="Revenue" fill="#1d6fdc" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></div>
        <div className="card"><h2>Orders by status</h2><div className="chart-box"><ResponsiveContainer><PieChart><Pie data={r.byStatus} dataKey="count" nameKey="status" outerRadius={95} label>{r.byStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer></div></div></div>
      <div className="grid g2"><div className="card"><h2 style={{ marginBottom: 10 }}>Sales by product</h2><div className="table-wrap"><table><thead><tr><th>Product</th><th className="num">Units</th><th className="num">Sales</th></tr></thead><tbody>{r.byProduct.map((p) => <tr key={p.model_number}><td>{p.product_name}<small style={{ display: 'block', color: 'var(--muted)' }}>{p.model_number}</small></td><td className="num">{p.units}</td><td className="num">{money2(p.sales)}</td></tr>)}{!r.byProduct.length && <tr><td colSpan="3">No sales in this period.</td></tr>}</tbody></table></div></div>
        <div className="card"><h2 style={{ marginBottom: 10 }}>Top customers</h2><div className="table-wrap"><table><thead><tr><th>Customer</th><th className="num">Orders</th><th className="num">Spent</th></tr></thead><tbody>{r.topCustomers.map((c) => <tr key={c.id}><td><Link to={`/users/${c.id}`}>{c.full_name}</Link><small style={{ display: 'block', color: 'var(--muted)' }}>{c.company || ''}</small></td><td className="num">{c.orders}</td><td className="num">{money(c.spent)}</td></tr>)}{!r.topCustomers.length && <tr><td colSpan="3">No orders in this period.</td></tr>}</tbody></table></div>
          <h2 style={{ margin: '16px 0 8px' }}>Calls by status</h2><div className="filters">{r.callsByStatus.map((c) => <span key={c.status} className="badge blue">{c.status}: {c.count}</span>)}</div></div></div></>}</Async></>;
}
