import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api, { imgUrl, errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Confirm, Thumb, Field, money2, money, dt, d, useDebounced } from '../components/ui';

const STATUSES = ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Completed', 'Cancelled'];
export function Orders() {
  const { isStaff } = useAuth(); const [search, setSearch] = useState(''); const [status, setStatus] = useState(''); const [pay, setPay] = useState(''); const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [page, setPage] = useState(1);
  const s = useDebounced(search); const rs = (fn) => (e) => { fn(e.target.value); setPage(1); };
  const q = useFetch('/orders', { search: s, status: status || undefined, payment_status: pay || undefined, from: from || undefined, to: to || undefined, page });
  return <><PageHead title={isStaff ? 'Orders' : 'My orders'} sub="Search by order number, customer or date" />
    <div className="filters"><input className="wide" placeholder="Order number or customer" value={search} onChange={rs(setSearch)} aria-label="Search orders" />
      <select value={status} onChange={rs(setStatus)} aria-label="Status"><option value="">All statuses</option>{STATUSES.map((x) => <option key={x}>{x}</option>)}</select>
      <select value={pay} onChange={rs(setPay)} aria-label="Payment"><option value="">All payments</option>{['Unpaid', 'Partial', 'Paid', 'Refunded'].map((x) => <option key={x}>{x}</option>)}</select>
      <input type="date" value={from} onChange={rs(setFrom)} aria-label="From date" /><input type="date" value={to} onChange={rs(setTo)} aria-label="To date" /></div>
    <Async q={q} empty={<Empty title="No orders found" hint="Orders are created from confirmed bookings." />}>{(r) => <><div className="table-wrap"><table>
      <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Status</th><th>Payment</th><th className="num">Total</th><th /></tr></thead><tbody>
        {r.data.map((o) => <tr key={o.id}><td><Link to={`/orders/${o.id}`}>{o.order_number}</Link></td><td>{o.customer_name}</td><td>{dt(o.created_at)}</td><td><Badge>{o.status}</Badge></td><td><Badge>{o.payment_status}</Badge></td><td className="num">{money(o.grand_total)}</td><td><Link className="btn sm" to={`/orders/${o.id}`}>View</Link></td></tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setPage} /></>}</Async></>;
}

export function OrderDetails() {
  const { id } = useParams(); const { isStaff, toast } = useAuth(); const q = useFetch(`/orders/${id}`);
  const [status, setStatus] = useState(''); const [note, setNote] = useState(''); const [ask, setAsk] = useState(false); const [pay, setPay] = useState({ payment_status: 'Paid', method: 'Bank Transfer', reference: '', amount: '' }); const [perr, setPerr] = useState({});
  const setSt = async () => { try { await api.patch(`/orders/${id}/status`, { status, note }); toast('Order status updated'); setAsk(false); setStatus(''); setNote(''); q.reload(); } catch (e) { toast(errMsg(e), 'error'); setAsk(false); } };
  const savePay = async (e) => { e.preventDefault(); setPerr({}); try { await api.patch(`/orders/${id}/payment`, pay); toast('Payment updated'); q.reload(); } catch (e2) { setPerr(fieldErrs(e2)); toast(errMsg(e2), 'error'); } };
  return <Async q={q}>{(o) => { const open = !['Completed', 'Cancelled'].includes(o.status); return <><PageHead title={`Order ${o.order_number}`} sub={`Created ${dt(o.created_at)}`}><Link className="btn" to="/orders">Back</Link>{o.booking_id && isStaff && <Link className="btn" to={`/bookings/${o.booking_id}`}>Booking {o.booking_code}</Link>}</PageHead>
    <div className="grid g2"><div className="card"><h2>Summary</h2><dl className="kv"><dt>Status</dt><dd><Badge>{o.status}</Badge></dd><dt>Payment</dt><dd><Badge>{o.payment_status}</Badge></dd><dt>Customer</dt><dd>{isStaff ? <Link to={`/users/${o.user_id}`}>{o.customer_name}</Link> : o.customer_name}</dd><dt>Contact</dt><dd>{o.delivery_name} · <a href={`tel:${o.delivery_phone}`}>{o.delivery_phone}</a></dd><dt>Deliver to</dt><dd>{o.delivery_address || '—'}</dd><dt>Instructions</dt><dd>{o.special_instructions || '—'}</dd></dl></div>
      <div className="card"><h2>History</h2><ul className="timeline">{o.history.map((h) => <li key={h.id}><strong>{h.status}</strong> <small>{dt(h.created_at)}{h.changed_by_name ? ` · ${h.changed_by_name}` : ''}</small>{h.note && <div>{h.note}</div>}</li>)}</ul></div></div>
    <div className="card"><h2 style={{ marginBottom: 10 }}>Items</h2><div className="table-wrap"><table><thead><tr><th>Product</th><th className="num">Qty</th><th className="num">List price</th><th className="num">Price paid</th><th className="num">Line total</th></tr></thead><tbody>
      {o.items.map((i) => <tr key={i.id}><td><div className="cell"><Thumb src={imgUrl(i.image_url)} /><div>{i.product_name}<small>{i.model_number}</small></div></div></td><td className="num">{i.quantity}</td><td className="num">{money2(i.unit_price)}</td><td className="num">{money2(Number(i.discount_price) > 0 ? i.discount_price : i.unit_price)}</td><td className="num">{money2(i.line_total)}</td></tr>)}</tbody></table></div>
      <div className="totals"><div><span>Subtotal (list)</span><span>{money2(o.subtotal)}</span></div><div><span>Discounts</span><span>− {money2(o.discount_total)}</span></div><div><span>Tax</span><span>{money2(o.tax_amount)}</span></div><div><span>Shipping</span><span>{money2(o.shipping_amount)}</span></div><div className="grand"><span>Grand total</span><span>{money2(o.grand_total)}</span></div></div></div>
    {isStaff && <div className="grid g2">
      <div className="card"><h2>Update status</h2>{open ? <><Field label="New status"><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Select…</option>{STATUSES.filter((s) => s !== o.status).map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="Note (optional)"><input value={note} onChange={(e) => setNote(e.target.value)} /></Field><button className="btn primary" disabled={!status} onClick={() => setAsk(true)}>Update status</button></> : <p>This order is {o.status.toLowerCase()} and can no longer change.</p>}</div>
      <div className="card"><h2>Payment tracking</h2><form onSubmit={savePay}><div className="form-grid"><Field label="Payment status"><select value={pay.payment_status} onChange={(e) => setPay({ ...pay, payment_status: e.target.value })}>{['Unpaid', 'Partial', 'Paid', 'Refunded'].map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="Method"><select value={pay.method} onChange={(e) => setPay({ ...pay, method: e.target.value })}>{['Bank Transfer', 'UPI', 'Cash', 'Card', 'Other'].map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="Amount (blank = grand total)" error={perr.amount}><input type="number" min="0" step="0.01" value={pay.amount} onChange={(e) => setPay({ ...pay, amount: e.target.value })} /></Field>
        <Field label="Reference"><input value={pay.reference} onChange={(e) => setPay({ ...pay, reference: e.target.value })} placeholder="Transaction / receipt no." /></Field></div>
        <p style={{ color: 'var(--muted)', fontSize: '.85rem' }}>Records status only. No card details are collected; connect a payment gateway separately when credentials are available.</p><button className="btn primary">Save payment</button></form></div></div>}
    {o.payments.length > 0 && <div className="card"><h2 style={{ marginBottom: 10 }}>Payments</h2><div className="table-wrap"><table><thead><tr><th>Date</th><th>Method</th><th>Reference</th><th>Status</th><th className="num">Amount</th></tr></thead><tbody>{o.payments.map((p) => <tr key={p.id}><td>{dt(p.created_at)}</td><td>{p.method}</td><td>{p.reference || '—'}</td><td><Badge>{p.status === 'Completed' ? 'Paid' : p.status}</Badge></td><td className="num">{money2(p.amount)}</td></tr>)}</tbody></table></div></div>}
    {ask && <Confirm danger={status === 'Cancelled'} title="Update order status" message={status === 'Cancelled' ? 'Cancel this order? Stock will be returned to inventory and the order cannot be reopened.' : `Change status to ${status}?`} confirmLabel="Update status" onConfirm={setSt} onCancel={() => setAsk(false)} />}</>; }}</Async>;
}
