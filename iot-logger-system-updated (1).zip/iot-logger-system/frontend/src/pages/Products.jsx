import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api, { imgUrl, errMsg } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Confirm, money, effPrice, useDebounced } from '../components/ui';

export function ProductCard({ p, manage, onDelete }) {
  const { isAdmin } = useAuth(); const out = p.stock_quantity <= 0; const disc = Number(p.discount_price) > 0;
  return <div className="pcard">
    {p.image_url ? <img src={imgUrl(p.image_url)} alt={p.name} loading="lazy" /> : <div className="ph-img">No image</div>}
    <div className="pcard-b"><div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}><h3>{p.name}</h3>{manage && <Badge>{p.status}</Badge>}</div>
      <div className="model">Model {p.model_number} · {p.connectivity} · {p.channels} ch</div>
      <div className="price">{money(effPrice(p))}{disc && <s>{money(p.unit_price)}</s>}</div>
      <div><Badge>{p.stock_status}</Badge> <small style={{ color: 'var(--muted)' }}>{p.stock_quantity} in stock</small></div></div>
    <div className="pcard-f"><Link className="btn" to={`/catalogue/${p.id}`}>View Details</Link>
      {manage && isAdmin ? <><Link className="btn" to={`/products/${p.id}/edit`}>Edit</Link><button className="btn danger" onClick={() => onDelete(p)}>Delete</button></>
        : <Link className={`btn primary ${out || p.status !== 'Active' ? 'disabled' : ''}`} aria-disabled={out} to={out ? '#' : `/book/${p.id}`} onClick={(e) => out && e.preventDefault()} style={out ? { opacity: .5 } : null}>{out ? 'Out of stock' : 'Book Now'}</Link>}</div></div>;
}

export default function Products({ manage }) {
  const { toast, isAdmin } = useAuth(); const [sp, setSp] = useSearchParams();
  const [search, setSearch] = useState(sp.get('search') || ''); const [page, setPage] = useState(1); const [conn, setConn] = useState(''); const [status, setStatus] = useState('');
  const s = useDebounced(search); const [del, setDel] = useState(null);
  const q = useFetch('/products', { search: s, page, limit: 12, connectivity: conn || undefined, status: manage && status ? status : undefined });
  const remove = async () => { try { await api.delete(`/products/${del.id}`); toast('Product deleted'); setDel(null); q.reload(); } catch (e) { toast(errMsg(e), 'error'); setDel(null); } };
  return <><PageHead title={manage ? 'Data Logger Products' : 'Product Catalogue'} sub={manage ? 'Add, edit and retire data logger models' : 'Browse IoT data loggers and book the ones you need'}>
    {manage && isAdmin && <Link className="btn primary" to="/products/new">Add data logger</Link>}</PageHead>
    <div className="filters"><input className="wide" placeholder="Search by name, model or type" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); setSp({}); }} aria-label="Search" />
      <select value={conn} onChange={(e) => { setConn(e.target.value); setPage(1); }} aria-label="Connectivity"><option value="">All connectivity</option>{['Wi-Fi', 'Bluetooth', 'USB', 'Ethernet', 'Cellular'].map((c) => <option key={c}>{c}</option>)}</select>
      {manage && <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Status"><option value="">All statuses</option>{['Active', 'Inactive', 'Discontinued'].map((c) => <option key={c}>{c}</option>)}</select>}</div>
    <Async q={q} empty={<Empty title="No data loggers found" hint="Try a different search or clear the filters." />}>{(r) => <><div className="products">{r.data.map((p) => <ProductCard key={p.id} p={p} manage={manage} onDelete={setDel} />)}</div><Pagination meta={r.meta} onPage={setPage} /></>}</Async>
    {del && <Confirm danger title="Delete product" message={`Delete ${del.name} (${del.model_number})? This cannot be undone. Products with orders cannot be deleted; mark them Discontinued instead.`} confirmLabel="Delete product" onConfirm={remove} onCancel={() => setDel(null)} />}</>;
}
