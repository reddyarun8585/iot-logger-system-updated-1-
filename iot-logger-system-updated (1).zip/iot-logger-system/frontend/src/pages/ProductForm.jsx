import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import api, { imgUrl, errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { Field, PageHead, Loading } from '../components/ui';

const blank = { name: '', model_number: '', logger_type: '', channels: 1, measurement_range: '', connectivity: 'Wi-Fi', stock_quantity: 0, unit_price: '', discount_price: '', status: 'Active', description: '' };
export default function ProductForm() {
  const { id } = useParams(); const nav = useNavigate(); const { toast } = useAuth();
  const [f, setF] = useState(blank); const [file, setFile] = useState(null); const [preview, setPreview] = useState(''); const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false); const [loading, setLoading] = useState(!!id);
  useEffect(() => { if (id) api.get(`/products/${id}`).then((r) => { setF({ ...blank, ...r.data, discount_price: r.data.discount_price ?? '', measurement_range: r.data.measurement_range || '', description: r.data.description || '' }); setPreview(imgUrl(r.data.image_url)); }).catch((e) => toast(errMsg(e), 'error')).finally(() => setLoading(false)); }, [id]); // eslint-disable-line
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const pick = (e) => { const x = e.target.files[0]; if (!x) return; if (!['image/jpeg', 'image/png', 'image/webp'].includes(x.type)) return setErrs({ image: 'Choose a JPG, PNG or WEBP image' }); if (x.size > 2 * 1024 * 1024) return setErrs({ image: 'Image must be 2 MB or smaller' }); setErrs({}); setFile(x); setPreview(URL.createObjectURL(x)); };
  const submit = async (e) => { e.preventDefault(); setBusy(true); setErrs({});
    const fd = new FormData(); ['name', 'model_number', 'logger_type', 'channels', 'measurement_range', 'connectivity', 'unit_price', 'discount_price', 'status', 'description'].forEach((k) => fd.append(k, f[k] ?? ''));
    fd.append('stock_quantity', f.stock_quantity); if (file) fd.append('image', file);
    try { id ? await api.put(`/products/${id}`, fd) : await api.post('/products', fd); toast(id ? 'Data logger updated' : 'Data logger added'); nav('/products'); }
    catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } finally { setBusy(false); } };
  if (loading) return <Loading />;
  return <><PageHead title={id ? 'Edit data logger' : 'Add data logger'}><Link className="btn" to="/products">Cancel</Link></PageHead>
    <form className="card" onSubmit={submit} noValidate><div className="form-grid">
      <Field label="Product name" error={errs.name}><input value={f.name} onChange={set('name')} /></Field>
      <Field label="Model number" error={errs.model_number}><input value={f.model_number} onChange={set('model_number')} /></Field>
      <Field label="Logger type" error={errs.logger_type}><input value={f.logger_type} onChange={set('logger_type')} placeholder="Temperature, Pressure, Multi-channel…" /></Field>
      <Field label="Number of channels" error={errs.channels}><input type="number" min="1" value={f.channels} onChange={set('channels')} /></Field>
      <Field label="Measurement range" error={errs.measurement_range}><input value={f.measurement_range} onChange={set('measurement_range')} placeholder="-40 to 85 °C" /></Field>
      <Field label="Connectivity" error={errs.connectivity}><select value={f.connectivity} onChange={set('connectivity')}>{['Wi-Fi', 'Bluetooth', 'USB', 'Ethernet', 'Cellular'].map((c) => <option key={c}>{c}</option>)}</select></Field>
      <Field label="Unit price (₹)" error={errs.unit_price}><input type="number" min="0" step="0.01" value={f.unit_price} onChange={set('unit_price')} /></Field>
      <Field label="Discount price (₹, optional)" error={errs.discount_price}><input type="number" min="0" step="0.01" value={f.discount_price} onChange={set('discount_price')} /></Field>
      <Field label="Available stock" error={errs.stock_quantity} hint={id ? 'Change stock from Inventory & Pricing so it is logged' : undefined}><input type="number" min="0" value={f.stock_quantity} onChange={set('stock_quantity')} disabled={!!id} /></Field>
      <Field label="Status" error={errs.status}><select value={f.status} onChange={set('status')}>{['Active', 'Inactive', 'Discontinued'].map((c) => <option key={c}>{c}</option>)}</select></Field>
      <div className="full"><Field label="Description" error={errs.description}><textarea value={f.description} onChange={set('description')} /></Field></div>
      <div className="full"><Field label="Product image" error={errs.image} hint="JPG, PNG or WEBP, up to 2 MB"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={pick} /></Field>
        {preview && <img src={preview} alt="Preview" style={{ maxWidth: 220, borderRadius: 8, border: '1px solid var(--line)' }} />}</div></div>
      <div className="actions"><Link className="btn" to="/products">Cancel</Link><button className="btn primary" disabled={busy}>{busy ? 'Saving…' : id ? 'Save changes' : 'Add data logger'}</button></div></form></>;
}
