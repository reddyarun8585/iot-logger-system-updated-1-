import { useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Modal, Field, Confirm, d, useDebounced } from '../components/ui';

const blank = { full_name: '', email: '', phone: '', company: '', address: '', role: 'Customer', password: '' };
function UserModal({ user, onClose, onSaved }) {
  const { toast } = useAuth(); const [f, setF] = useState(user ? { ...blank, ...user, company: user.company || '', address: user.address || '', password: '' } : blank); const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async (e) => { e.preventDefault(); setBusy(true); setErrs({}); try { user ? await api.put(`/users/${user.id}`, f) : await api.post('/users', f); toast(user ? 'User updated' : 'User added'); onSaved(); } catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } finally { setBusy(false); } };
  return <Modal title={user ? 'Edit user' : 'Add user'} onClose={onClose} wide><form onSubmit={save} noValidate><div className="form-grid">
    <Field label="Full name" error={errs.full_name}><input value={f.full_name} onChange={set('full_name')} /></Field><Field label="Email" error={errs.email}><input type="email" value={f.email} onChange={set('email')} /></Field>
    <Field label="Phone" error={errs.phone}><input value={f.phone} onChange={set('phone')} /></Field><Field label="Role" error={errs.role}><select value={f.role} onChange={set('role')}>{['Admin', 'Staff', 'Customer'].map((r) => <option key={r}>{r}</option>)}</select></Field>
    <Field label="Company"><input value={f.company} onChange={set('company')} /></Field><Field label={user ? 'New password (optional)' : 'Password'} error={errs.password}><input type="password" value={f.password} onChange={set('password')} autoComplete="new-password" /></Field>
    <div className="full"><Field label="Address"><input value={f.address} onChange={set('address')} /></Field></div></div>
    <div className="actions"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save user'}</button></div></form></Modal>;
}
export default function Users() {
  const { isAdmin, toast, user: me } = useAuth(); const [search, setSearch] = useState(''); const [role, setRole] = useState(''); const [status, setStatus] = useState(''); const [page, setPage] = useState(1);
  const [edit, setEdit] = useState(null); const [tog, setTog] = useState(null); const s = useDebounced(search);
  const q = useFetch('/users', { search: s, role: role || undefined, status: status || undefined, page });
  const toggle = async () => { try { await api.patch(`/users/${tog.id}/status`, { is_active: !tog.is_active }); toast(tog.is_active ? 'User deactivated' : 'User activated'); setTog(null); q.reload(); } catch (e) { toast(errMsg(e), 'error'); setTog(null); } };
  const rs = (fn) => (e) => { fn(e.target.value); setPage(1); };
  return <><PageHead title="User management" sub="Customers, staff and administrators">{isAdmin && <button className="btn primary" onClick={() => setEdit({})}>Add user</button>}</PageHead>
    <div className="filters"><input className="wide" placeholder="Search name, email, phone or company" value={search} onChange={rs(setSearch)} aria-label="Search users" />
      <select value={role} onChange={rs(setRole)} aria-label="Role"><option value="">All roles</option>{['Admin', 'Staff', 'Customer'].map((r) => <option key={r}>{r}</option>)}</select>
      <select value={status} onChange={rs(setStatus)} aria-label="Status"><option value="">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
    <Async q={q} empty={<Empty title="No users match" hint="Adjust the search or filters." />}>{(r) => <><div className="table-wrap"><table><thead><tr><th>Name</th><th>Contact</th><th>Company</th><th>Role</th><th>Status</th><th>Joined</th><th /></tr></thead><tbody>
      {r.data.map((u) => <tr key={u.id}><td><Link to={`/users/${u.id}`}>{u.full_name}</Link></td><td>{u.email}<small style={{ display: 'block', color: 'var(--muted)' }}><a href={`tel:${u.phone}`}>{u.phone}</a></small></td><td>{u.company || '—'}</td><td><Badge>{u.role}</Badge></td><td><Badge>{u.is_active ? 'Active' : 'Inactive'}</Badge></td><td>{d(u.created_at)}</td>
        <td><div className="row-actions"><Link className="btn sm" to={`/users/${u.id}`}>History</Link>{isAdmin && <><button className="btn sm" onClick={() => setEdit(u)}>Edit</button>{u.id !== me.id && <button className="btn sm" onClick={() => setTog(u)}>{u.is_active ? 'Deactivate' : 'Activate'}</button>}</>}</div></td></tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setPage} /></>}</Async>
    {edit && <UserModal user={edit.id ? edit : null} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); q.reload(); }} />}
    {tog && <Confirm danger={tog.is_active} title={tog.is_active ? 'Deactivate user' : 'Activate user'} message={tog.is_active ? `${tog.full_name} will no longer be able to log in.` : `${tog.full_name} will be able to log in again.`} confirmLabel={tog.is_active ? 'Deactivate' : 'Activate'} onConfirm={toggle} onCancel={() => setTog(null)} />}</>;
}
