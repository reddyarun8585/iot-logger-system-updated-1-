import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api, { imgUrl, errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { Field, PageHead, Loading, money, effPrice, Thumb } from '../components/ui';

export default function BookingForm() {
  const { id } = useParams(); const { user, toast } = useAuth(); const nav = useNavigate();
  const [products, setProducts] = useState(null); const [items, setItems] = useState([{ id: Number(id), qty: 1 }]);
  const today = new Date().toISOString().slice(0, 10);
  const [f, setF] = useState({ delivery_name: user.full_name, delivery_phone: '', delivery_address: '', booking_date: today, special_instructions: '' }); const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false);
  useEffect(() => { api.get('/products', { params: { limit: 100 } }).then((r) => setProducts(r.data.data)).catch((e) => toast(errMsg(e), 'error'));
    api.get('/auth/me').then((r) => setF((x) => ({ ...x, delivery_phone: r.data.phone || '', delivery_address: r.data.address || '' }))).catch(() => {}); }, []); // eslint-disable-line
  if (!products) return <Loading />;
  const byId = Object.fromEntries(products.map((p) => [p.id, p]));
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const setItem = (i, patch) => setItems(items.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const total = items.reduce((s, x) => s + (byId[x.id] ? effPrice(byId[x.id]) * (Number(x.qty) || 0) : 0), 0);
  const stockErr = (x) => { const p = byId[x.id]; if (!p) return 'Choose a product'; const q = Number(x.qty); if (!Number.isInteger(q) || q < 1) return 'Enter a whole number of 1 or more'; if (q > p.stock_quantity) return `Only ${p.stock_quantity} in stock`; return ''; };
  const submit = async (e) => { e.preventDefault(); setErrs({});
    if (items.some(stockErr)) return toast('Check the product quantities', 'error');
    setBusy(true);
    try { const { data } = await api.post('/bookings', { ...f, items: items.map((x) => ({ data_logger_id: x.id, quantity: Number(x.qty) })) }); toast(`Booking submitted. Your booking ID is ${data.booking_code}`); nav(`/bookings/${data.id}`); }
    catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } finally { setBusy(false); } };
  return <><PageHead title="Book data loggers" sub="Submit a booking request. Our team will confirm it and create your order." />
    <form onSubmit={submit} noValidate><div className="card"><h2 style={{ marginBottom: 12 }}>Products</h2>
      {items.map((x, i) => { const p = byId[x.id]; const e = stockErr(x); return <div key={i} className="grid" style={{ gridTemplateColumns: '1fr 120px auto', alignItems: 'start', marginBottom: 10 }}>
        <Field label={i === 0 ? 'Product' : ''}><div className="cell">{p && <Thumb src={imgUrl(p.image_url)} />}<select value={x.id} onChange={(ev) => setItem(i, { id: Number(ev.target.value) })}>{!p && <option value="">Select…</option>}{products.filter((q) => q.stock_quantity > 0 || q.id === x.id).map((q) => <option key={q.id} value={q.id}>{q.name} ({q.model_number}) — {money(effPrice(q))}</option>)}</select></div></Field>
        <Field label={i === 0 ? 'Quantity' : ''} error={e}><input type="number" min="1" value={x.qty} onChange={(ev) => setItem(i, { qty: ev.target.value })} /></Field>
        <div style={{ paddingTop: i === 0 ? 24 : 0 }}>{items.length > 1 && <button type="button" className="btn sm" onClick={() => setItems(items.filter((_, j) => j !== i))}>Remove</button>}</div></div>; })}
      <button type="button" className="btn sm" onClick={() => setItems([...items, { id: products.find((p) => p.stock_quantity > 0 && !items.some((x) => x.id === p.id))?.id || '', qty: 1 }])}>Add another product</button>
      <p style={{ textAlign: 'right', fontSize: '1.1rem' }}>Estimated total (before tax and shipping): <strong>{money(total)}</strong></p></div>
    <div className="card"><h2 style={{ marginBottom: 12 }}>Delivery details</h2><div className="form-grid">
      <Field label="Contact name" error={errs.delivery_name}><input value={f.delivery_name} onChange={set('delivery_name')} /></Field>
      <Field label="Contact phone" error={errs.delivery_phone}><input value={f.delivery_phone} onChange={set('delivery_phone')} /></Field>
      <div className="full"><Field label="Delivery address" error={errs.delivery_address}><input value={f.delivery_address} onChange={set('delivery_address')} /></Field></div>
      <Field label="Booking date" error={errs.booking_date}><input type="date" min={today} value={f.booking_date} onChange={set('booking_date')} /></Field>
      <div className="full"><Field label="Special instructions (optional)"><textarea value={f.special_instructions} onChange={set('special_instructions')} /></Field></div></div>
      <div className="actions"><Link className="btn" to="/catalogue">Cancel</Link><button className="btn primary" disabled={busy}>{busy ? 'Submitting…' : 'Submit booking request'}</button></div></div></form></>;
}
