import { useParams, Link } from 'react-router-dom';
import { imgUrl } from '../api';
import { useFetch, Async, Badge, PageHead, money, effPrice } from '../components/ui';

export default function ProductDetails() {
  const { id } = useParams(); const q = useFetch(`/products/${id}`);
  return <Async q={q}>{(p) => { const out = p.stock_quantity <= 0; return <><PageHead title={p.name} sub={`Model ${p.model_number}`}><Link className="btn" to="/catalogue">Back to catalogue</Link></PageHead>
    <div className="detail card">{p.image_url ? <img src={imgUrl(p.image_url)} alt={p.name} /> : <div className="ph-img" style={{ aspectRatio: '3/2' }}>No image</div>}
      <div><div className="price" style={{ fontSize: '1.6rem' }}>{money(effPrice(p))}{Number(p.discount_price) > 0 && <s>{money(p.unit_price)}</s>}</div>
        <p><Badge>{p.stock_status}</Badge> {p.stock_quantity} units available</p><p>{p.description}</p>
        <dl className="kv"><dt>Logger type</dt><dd>{p.logger_type}</dd><dt>Channels</dt><dd>{p.channels}</dd><dt>Measurement range</dt><dd>{p.measurement_range || '—'}</dd><dt>Connectivity</dt><dd>{p.connectivity}</dd></dl>
        <div className="actions" style={{ justifyContent: 'flex-start', marginTop: 16 }}>{out ? <button className="btn" disabled>Out of stock</button> : <Link className="btn primary" to={`/book/${p.id}`}>Book Now</Link>}</div></div></div></>; }}</Async>;
}
