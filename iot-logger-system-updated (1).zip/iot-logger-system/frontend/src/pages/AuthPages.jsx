import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth';
import { errMsg, fieldErrs } from '../api';
import { Field } from '../components/ui';

function Shell({ title, sub, children }) {
  return <div className="auth">
    <aside className="auth-art">
      <div className="auth-brand"><i>◉</i>SensorLink</div>
      <div className="auth-copy">
        <h1>Real-time monitoring from checkout to delivery.</h1>
        <p>Manage data logger stock, bookings, orders and customer follow-ups in one place.</p>
        <ul className="auth-points">
          <li>Live logger inventory</li>
          <li>Booking and order tracking</li>
          <li>Customer follow-up history</li>
        </ul>
      </div>
    </aside>
    <main className="auth-form"><div className="auth-card"><h2>{title}</h2><p className="auth-sub">{sub}</p>{children}</div></main>
  </div>;
}
export function Login() {
  const { login, toast } = useAuth(); const nav = useNavigate(); const loc = useLocation();
  const [f, setF] = useState({ email: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async (e) => { e.preventDefault(); setBusy(true); setErr('');
    try { const u = await login(f.email, f.password); toast(`Welcome back, ${u.full_name.split(' ')[0]}`); nav(loc.state?.from || '/'); } catch (e2) { setErr(errMsg(e2)); } finally { setBusy(false); } };
  return <Shell title="Log in" sub="Use your account email and password.">
    <form onSubmit={submit} noValidate>{err && <div className="alert error">{err}</div>}
      <Field label="Email"><input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} autoComplete="username" required /></Field>
      <Field label="Password"><input type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="current-password" required /></Field>
      <button className="btn primary" style={{ width: '100%' }} disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
      <p style={{ marginTop: 14 }}>New customer? <Link to="/register">Create an account</Link> · <Link to="/catalogue">Browse catalogue</Link></p></form></Shell>;
}
export function Register() {
  const { register, toast } = useAuth(); const nav = useNavigate();
  const [f, setF] = useState({ full_name: '', email: '', phone: '', company: '', address: '', password: '' }); const [errs, setErrs] = useState({}); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => { e.preventDefault(); setBusy(true); setErrs({}); setMsg('');
    try { await register(f); toast('Account created'); nav('/catalogue'); } catch (e2) { setErrs(fieldErrs(e2)); setMsg(errMsg(e2)); } finally { setBusy(false); } };
  return <Shell title="Create your account" sub="Customers can browse loggers and place booking requests.">
    <form onSubmit={submit} noValidate>{msg && <div className="alert error">{msg}</div>}
      <Field label="Full name" error={errs.full_name}><input value={f.full_name} onChange={set('full_name')} /></Field>
      <Field label="Email" error={errs.email}><input type="email" value={f.email} onChange={set('email')} /></Field>
      <Field label="Phone number" error={errs.phone}><input value={f.phone} onChange={set('phone')} placeholder="+91 98765 43210" /></Field>
      <Field label="Company (optional)"><input value={f.company} onChange={set('company')} /></Field>
      <Field label="Address (optional)"><input value={f.address} onChange={set('address')} /></Field>
      <Field label="Password" error={errs.password} hint="At least 8 characters with a letter and a number"><input type="password" value={f.password} onChange={set('password')} autoComplete="new-password" /></Field>
      <button className="btn primary" style={{ width: '100%' }} disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
      <p style={{ marginTop: 14 }}>Already registered? <Link to="/login">Log in</Link></p></form></Shell>;
}
