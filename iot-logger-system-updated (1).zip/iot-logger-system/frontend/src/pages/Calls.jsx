import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import api, { errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Field, Confirm, Loading, dt, d, useDebounced } from '../components/ui';

const STATUS = ['Scheduled', 'Completed', 'Missed', 'Follow-up Required'];
export function Calls() {
  const { isAdmin, toast } = useAuth(); const [sp] = useSearchParams();
  const [search, setSearch] = useState(''); const [status, setStatus] = useState(sp.get('status') || ''); const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [page, setPage] = useState(1); const [del, setDel] = useState(null);
  const s = useDebounced(search); const rs = (fn) => (e) => { fn(e.target.value); setPage(1); };
  const q = useFetch('/calls', { search: s, status: status || undefined, from: from || undefined, to: to || undefined, page });
  const remove = async () => { try { await api.delete(`/calls/${del.id}`); toast('Call record deleted'); setDel(null); q.reload(); } catch (e) { toast(errMsg(e), 'error'); setDel(null); } };
  return <><PageHead title="Call members" sub="Customer calls and follow-ups"><Link className="btn primary" to="/calls/new">Add call record</Link></PageHead>
    <div className="filters"><input className="wide" placeholder="Search customer, phone or purpose" value={search} onChange={rs(setSearch)} aria-label="Search calls" />
      <select value={status} onChange={rs(setStatus)} aria-label="Status"><option value="">All statuses</option>{STATUS.map((x) => <option key={x}>{x}</option>)}</select>
      <input type="date" value={from} onChange={rs(setFrom)} aria-label="From" /><input type="date" value={to} onChange={rs(setTo)} aria-label="To" /></div>
    <Async q={q} empty={<Empty title="No call records" hint="Log your first customer call."><p><Link className="btn primary" to="/calls/new">Add call record</Link></p></Empty>}>{(r) => <><div className="table-wrap"><table>
      <thead><tr><th>Customer</th><th>Phone</th><th>Call time</th><th>Purpose</th><th>Status</th><th>Next follow-up</th><th>Staff</th><th /></tr></thead><tbody>
        {r.data.map((c) => <tr key={c.id}><td>{c.customer_id ? <Link to={`/users/${c.customer_id}`}>{c.customer_name}</Link> : c.customer_name}</td><td><a className="btn sm" href={`tel:${c.phone.replace(/[^+\d]/g, '')}`} title="Opens your phone or calling app">📞 {c.phone}</a></td><td>{dt(c.call_datetime)}</td><td>{c.purpose}</td><td><Badge>{c.status}</Badge></td><td>{d(c.next_followup)}</td><td>{c.staff_name || '—'}</td>
          <td><div className="row-actions"><Link className="btn sm" to={`/calls/${c.id}/edit`}>Edit</Link>{isAdmin && <button className="btn sm" onClick={() => setDel(c)}>Delete</button>}</div></td></tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setPage} /></>}</Async>
    <p style={{ color: 'var(--muted)', fontSize: '.85rem' }}>The phone buttons use <code>tel:</code> links, which open your device’s dialer. The system does not place calls automatically.</p>
    {del && <Confirm danger title="Delete call record" message={`Delete the call record for ${del.customer_name}?`} confirmLabel="Delete" onConfirm={remove} onCancel={() => setDel(null)} />}</>;
}

const nowLocal = () => { const x = new Date(); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 16); };
export function CallForm() {
  const { id } = useParams(); const [sp] = useSearchParams(); const nav = useNavigate(); const { toast, user } = useAuth();
  const [f, setF] = useState({ customer_id: sp.get('customer') || '', customer_name: '', phone: '', email: '', call_datetime: nowLocal(), purpose: '', status: 'Scheduled', notes: '', next_followup: '', assigned_staff_id: user.id });
  const [mode, setMode] = useState('existing'); const [custs, setCusts] = useState([]); const [staff, setStaff] = useState([]); const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false); const [loading, setLoading] = useState(!!id);
  useEffect(() => { api.get('/users', { params: { role: 'Customer', limit: 200, status: 'active' } }).then((r) => setCusts(r.data.data)); api.get('/users', { params: { limit: 200, status: 'active' } }).then((r) => setStaff(r.data.data.filter((u) => u.role !== 'Customer')));
    if (id) api.get(`/calls/${id}`).then((r) => { const c = r.data; setF({ customer_id: c.customer_id || '', customer_name: c.customer_name, phone: c.phone, email: '', call_datetime: c.call_datetime.slice(0, 16).replace(' ', 'T'), purpose: c.purpose, status: c.status, notes: c.notes || '', next_followup: c.next_followup ? c.next_followup.slice(0, 10) : '', assigned_staff_id: c.assigned_staff_id || '' }); if (!c.customer_id) setMode('new'); }).catch((e) => toast(errMsg(e), 'error')).finally(() => setLoading(false)); }, [id]); // eslint-disable-line
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const pickCustomer = (e) => { const c = custs.find((x) => String(x.id) === e.target.value); setF({ ...f, customer_id: e.target.value, customer_name: c?.full_name || '', phone: c?.phone || '' }); };
  const submit = async (e) => { e.preventDefault(); setBusy(true); setErrs({});
    const body = { ...f, customer_id: mode === 'existing' ? f.customer_id || undefined : undefined };
    if (mode === 'existing' && !f.customer_id) { setErrs({ customer_id: 'Select a customer' }); setBusy(false); return; }
    try { id ? await api.put(`/calls/${id}`, body) : await api.post('/calls', body); toast(id ? 'Call record updated' : 'Call record added'); nav('/calls'); } catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } finally { setBusy(false); } };
  if (loading) return <Loading />;
  return <><PageHead title={id ? 'Edit call record' : 'Add call record'}><Link className="btn" to="/calls">Cancel</Link></PageHead>
    <form className="card" onSubmit={submit} noValidate>
      <div className="filters" style={{ marginBottom: 12 }}><label><input type="radio" style={{ width: 'auto' }} checked={mode === 'existing'} onChange={() => setMode('existing')} /> Existing customer</label><label><input type="radio" style={{ width: 'auto' }} checked={mode === 'new'} onChange={() => setMode('new')} /> New customer</label></div>
      <div className="form-grid">
        {mode === 'existing' ? <Field label="Customer" error={errs.customer_id}><select value={f.customer_id} onChange={pickCustomer}><option value="">Select customer…</option>{custs.map((c) => <option key={c.id} value={c.id}>{c.full_name}{c.company ? ` — ${c.company}` : ''}</option>)}</select></Field>
          : <Field label="Customer name" error={errs.customer_name}><input value={f.customer_name} onChange={set('customer_name')} /></Field>}
        <Field label="Phone number" error={errs.phone}><input value={f.phone} onChange={set('phone')} /></Field>
        {mode === 'new' && !id && <Field label="Email (optional)" error={errs.email} hint="Adds them as a customer account"><input type="email" value={f.email} onChange={set('email')} /></Field>}
        <Field label="Call date and time" error={errs.call_datetime}><input type="datetime-local" value={f.call_datetime} onChange={set('call_datetime')} /></Field>
        <Field label="Status" error={errs.status}><select value={f.status} onChange={set('status')}>{STATUS.map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="Next follow-up date" error={errs.next_followup}><input type="date" value={f.next_followup} onChange={set('next_followup')} /></Field>
        <Field label="Assigned staff"><select value={f.assigned_staff_id} onChange={set('assigned_staff_id')}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}</select></Field>
        <div className="full"><Field label="Call purpose" error={errs.purpose}><input value={f.purpose} onChange={set('purpose')} /></Field></div>
        <div className="full"><Field label="Notes"><textarea value={f.notes} onChange={set('notes')} /></Field></div></div>
      {f.phone && <p><a className="btn" href={`tel:${f.phone.replace(/[^+\d]/g, '')}`}>📞 Call {f.phone}</a></p>}
      <div className="actions"><Link className="btn" to="/calls">Cancel</Link><button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save call record'}</button></div></form></>;
}
