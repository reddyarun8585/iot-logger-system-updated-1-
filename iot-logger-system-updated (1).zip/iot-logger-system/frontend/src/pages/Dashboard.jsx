import { Link } from 'react-router-dom';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from 'recharts';
import { useFetch, Async, Stat, PageHead, Badge, money, dt } from '../components/ui';

export default function Dashboard() {
  const q = useFetch('/reports/dashboard');
  return <><PageHead title="Dashboard" sub="Business overview across loggers, bookings and orders" />
    <Async q={q}>{(r) => { const t = r.totals; return <>
      <div className="stats">
        <Stat label="Data loggers" value={t.loggers} /><Stat label="Registered users" value={t.users} /><Stat label="Bookings" value={t.bookings} />
        <Stat label="Orders" value={t.orders} /><Stat label="Pending orders" value={t.pending_orders} tone="warn" /><Stat label="Completed orders" value={t.completed_orders} tone="ok" />
        <Stat label="Total revenue" value={money(t.revenue)} sub="Excludes cancelled orders" tone="ok" /></div>
      <div className="grid g2">
        <div className="card"><h2>Data logger sales (units)</h2><div className="chart-box"><ResponsiveContainer><BarChart data={r.salesByLogger}><CartesianGrid strokeDasharray="3 3" stroke="#e3e9f3" /><XAxis dataKey="name" fontSize={12} /><YAxis allowDecimals={false} fontSize={12} /><Tooltip /><Bar dataKey="units" name="Units sold" fill="#1d6fdc" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></div>
        <div className="card"><h2>Monthly revenue</h2><div className="chart-box"><ResponsiveContainer><LineChart data={r.monthlyRevenue}><CartesianGrid strokeDasharray="3 3" stroke="#e3e9f3" /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} /><Tooltip formatter={(v) => money(v)} /><Line type="monotone" dataKey="revenue" name="Revenue" stroke="#0b2545" strokeWidth={2.5} dot /></LineChart></ResponsiveContainer></div></div>
      </div>
      <div className="grid g2">
        <div className="card"><div className="page-head" style={{ marginBottom: 8 }}><h2>Recent bookings</h2><Link to="/bookings">View all</Link></div>
          <div className="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th>Status</th><th className="num">Amount</th></tr></thead><tbody>
            {r.recentBookings.map((b) => <tr key={b.id}><td><Link to={`/bookings/${b.id}`}>{b.booking_code}</Link><small style={{ display: 'block', color: 'var(--muted)' }}>{dt(b.created_at)}</small></td><td>{b.customer_name}</td><td><Badge>{b.status}</Badge></td><td className="num">{money(b.total_amount)}</td></tr>)}</tbody></table></div></div>
        <div className="card"><div className="page-head" style={{ marginBottom: 8 }}><h2>Recent orders</h2><Link to="/orders">View all</Link></div>
          <div className="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Status</th><th className="num">Total</th></tr></thead><tbody>
            {r.recentOrders.map((o) => <tr key={o.id}><td><Link to={`/orders/${o.id}`}>{o.order_number}</Link><small style={{ display: 'block', color: 'var(--muted)' }}>{dt(o.created_at)}</small></td><td>{o.customer_name}</td><td><Badge>{o.status}</Badge></td><td className="num">{money(o.grand_total)}</td></tr>)}</tbody></table></div></div>
      </div></>; }}</Async></>;
}
