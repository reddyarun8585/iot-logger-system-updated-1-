import { useState } from 'react';
import api, { imgUrl, errMsg, fieldErrs } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Stat, Modal, Field, Thumb, money, money2, dt, useDebounced } from '../components/ui';

function EditModal({ p, onClose, onSaved }) {
  const { toast } = useAuth(); const [f, setF] = useState({ unit_price: p.unit_price, discount_price: p.discount_price ?? '', stock_quantity: p.stock_quantity, note: '' }); const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async (e) => { e.preventDefault(); setBusy(true); setErrs({}); try { await api.patch(`/inventory/${p.id}`, f); toast('Inventory updated'); onSaved(); } catch (e2) { setErrs(fieldErrs(e2)); toast(errMsg(e2), 'error'); } finally { setBusy(false); } };
  return <Modal title={`${p.name} (${p.model_number})`} onClose={onClose}><form onSubmit={save} noValidate>
    <Field label="Unit price (₹)" error={errs.unit_price} hint="Existing orders keep the price they were placed at"><input type="number" min="0" step="0.01" value={f.unit_price} onChange={set('unit_price')} /></Field>
    <Field label="Discount price (₹)" error={errs.discount_price}><input type="number" min="0" step="0.01" value={f.discount_price} onChange={set('discount_price')} /></Field>
    <Field label="Stock quantity" error={errs.stock_quantity}><input type="number" min="0" value={f.stock_quantity} onChange={set('stock_quantity')} /></Field>
    <Field label="Reason for stock change"><input value={f.note} onChange={set('note')} placeholder="e.g. New shipment received" /></Field>
    <div className="actions"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button></div></form></Modal>;
}
export default function Inventory() {
  const { isAdmin } = useAuth(); const [search, setSearch] = useState(''); const [page, setPage] = useState(1); const [tp, setTp] = useState(1); const [edit, setEdit] = useState(null); const s = useDebounced(search);
  const sum = useFetch('/inventory/summary'); const q = useFetch('/products', { search: s, page, limit: 10, status: undefined }, [edit]); const tx = useFetch('/inventory/transactions', { page: tp, limit: 8 }, [edit]);
  const done = () => { setEdit(null); sum.reload(); q.reload(); tx.reload(); };
  return <><PageHead title="Inventory and pricing" sub="Stock levels, prices and sales per data logger" />
    <Async q={sum}>{(m) => <div className="stats"><Stat label="Logger models" value={m.models} /><Stat label="Units in stock" value={m.units} tone="ok" /><Stat label="Low stock" value={m.low_stock} sub={`${m.threshold} units or fewer`} tone="warn" /><Stat label="Out of stock" value={m.out_of_stock} tone="bad" /></div>}</Async>
    <div className="filters"><input className="wide" placeholder="Search by name, model or type" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} aria-label="Search inventory" /></div>
    <Async q={q} empty={<Empty title="No products found" />}>{(r) => <><div className="table-wrap"><table><thead><tr><th>Product</th><th className="num">Unit price</th><th className="num">Discounted</th><th className="num">In stock</th><th className="num">Units sold</th><th className="num">Sales value</th><th>Status</th>{isAdmin && <th />}</tr></thead><tbody>
      {r.data.map((p) => <tr key={p.id}><td><div className="cell"><Thumb src={imgUrl(p.image_url)} /><div>{p.name}<small>{p.model_number}</small></div></div></td><td className="num">{money2(p.unit_price)}</td><td className="num">{Number(p.discount_price) > 0 ? money2(p.discount_price) : '—'}</td><td className="num">{p.stock_quantity}</td><td className="num">{p.units_sold}</td><td className="num">{money(p.total_sales)}</td><td><Badge>{p.stock_status}</Badge></td>{isAdmin && <td><button className="btn sm" onClick={() => setEdit(p)}>Update</button></td>}</tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setPage} /></>}</Async>
    <div className="card" style={{ marginTop: 18 }}><h2 style={{ marginBottom: 10 }}>Stock movements</h2><Async q={tx} empty={<Empty title="No stock movements yet" />}>{(r) => <><div className="table-wrap"><table><thead><tr><th>When</th><th>Product</th><th>Type</th><th className="num">Change</th><th className="num">Balance</th><th>Reference</th><th>By</th></tr></thead><tbody>
      {r.data.map((t) => <tr key={t.id}><td>{dt(t.created_at)}</td><td>{t.name}<small style={{ display: 'block', color: 'var(--muted)' }}>{t.model_number}</small></td><td>{t.type}</td><td className="num" style={{ color: t.change_qty < 0 ? 'var(--red)' : 'var(--green)' }}>{t.change_qty > 0 ? '+' : ''}{t.change_qty}</td><td className="num">{t.balance_after}</td><td>{t.reference || t.note || '—'}</td><td>{t.user_name || '—'}</td></tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setTp} /></>}</Async></div>
    {edit && <EditModal p={edit} onClose={() => setEdit(null)} onSaved={done} />}</>;
}
