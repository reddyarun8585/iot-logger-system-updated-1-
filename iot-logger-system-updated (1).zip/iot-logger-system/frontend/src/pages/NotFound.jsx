import { Link } from 'react-router-dom';
import { Empty } from '../components/ui';
export default function NotFound() { return <Empty title="404 · Page not found" hint="The page you are looking for does not exist or was moved."><p><Link className="btn primary" to="/">Back to home</Link></p></Empty>; }
