import { useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import api, { imgUrl, errMsg } from '../api';
import { useAuth } from '../auth';
import { useFetch, Async, Empty, Pagination, PageHead, Badge, Confirm, Thumb, money, money2, d, dt, useDebounced } from '../components/ui';

const FLOW = ['Pending', 'Confirmed', 'Processing', 'Completed'];
export function Bookings() {
  const { isStaff } = useAuth(); const [sp] = useSearchParams();
  const [search, setSearch] = useState(''); const [status, setStatus] = useState(sp.get('status') || ''); const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [page, setPage] = useState(1);
  const s = useDebounced(search); const q = useFetch('/bookings', { search: s, status: status || undefined, from: from || undefined, to: to || undefined, page });
  return <><PageHead title={isStaff ? 'Bookings' : 'My bookings'} sub="Track booking requests and their status">{!isStaff && <Link className="btn primary" to="/catalogue">New booking</Link>}</PageHead>
    <div className="filters">{isStaff && <input className="wide" placeholder="Search booking ID or customer" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} aria-label="Search bookings" />}
      <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Status"><option value="">All statuses</option>{[...FLOW, 'Cancelled'].map((x) => <option key={x}>{x}</option>)}</select>
      <input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} aria-label="From date" /><input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} aria-label="To date" /></div>
    <Async q={q} empty={<Empty title="No bookings yet" hint="Bookings appear here once a customer submits a request."><p><Link className="btn primary" to="/catalogue">Browse catalogue</Link></p></Empty>}>{(r) => <><div className="table-wrap"><table>
      <thead><tr><th>Booking ID</th>{isStaff && <th>Customer</th>}<th>Booking date</th><th>Status</th><th className="num">Amount</th><th>Order</th><th /></tr></thead><tbody>
        {r.data.map((b) => <tr key={b.id}><td><Link to={`/bookings/${b.id}`}>{b.booking_code}</Link></td>{isStaff && <td>{b.customer_name}</td>}<td>{d(b.booking_date)}</td><td><Badge>{b.status}</Badge></td><td className="num">{money(b.total_amount)}</td>
          <td>{b.order_id ? <Link to={`/orders/${b.order_id}`}>{b.order_number}</Link> : '—'}</td><td><Link className="btn sm" to={`/bookings/${b.id}`}>View</Link></td></tr>)}</tbody></table></div><Pagination meta={r.meta} onPage={setPage} /></>}</Async></>;
}

export function BookingDetails() {
  const { id } = useParams(); const { isStaff, toast } = useAuth(); const q = useFetch(`/bookings/${id}`); const [ask, setAsk] = useState(null);
  const act = async () => { try { if (ask.kind === 'order') await api.post(`/bookings/${id}/order`); else await api.patch(`/bookings/${id}/status`, { status: ask.status }); toast(ask.done); setAsk(null); q.reload(); } catch (e) { toast(errMsg(e), 'error'); setAsk(null); } };
  return <Async q={q}>{(b) => { const idx = FLOW.indexOf(b.status); return <><PageHead title={`Booking ${b.booking_code}`} sub={`Placed ${dt(b.created_at)}`}><Link className="btn" to="/bookings">Back</Link>
    {isStaff && b.status === 'Pending' && <button className="btn primary" onClick={() => setAsk({ status: 'Confirmed', title: 'Confirm booking', msg: 'Confirm this booking? You can then create an order from it.', done: 'Booking confirmed' })}>Confirm booking</button>}
    {isStaff && b.status === 'Confirmed' && !b.order_id && <button className="btn primary" onClick={() => setAsk({ kind: 'order', title: 'Create order', msg: 'Create an order from this booking? Stock will be deducted now.', done: 'Order created' })}>Create order</button>}
    {b.order_id && <Link className="btn primary" to={`/orders/${b.order_id}`}>View order {b.order_number}</Link>}
    {!b.order_id && ['Pending', 'Confirmed'].includes(b.status) && (isStaff || b.status === 'Pending') && <button className="btn danger" onClick={() => setAsk({ status: 'Cancelled', danger: true, title: 'Cancel booking', msg: 'Cancel this booking? This cannot be undone.', done: 'Booking cancelled' })}>Cancel booking</button>}</PageHead>
    {b.status === 'Cancelled' ? <div className="alert error">This booking was cancelled.</div> : <div className="steps">{FLOW.map((s, i) => <div key={s} className={`step ${i <= idx ? 'done' : ''} ${i === idx ? 'cur' : ''}`}>{s}</div>)}</div>}
    <div className="grid g2"><div className="card"><h2>Details</h2><dl className="kv"><dt>Status</dt><dd><Badge>{b.status}</Badge></dd><dt>Customer</dt><dd>{isStaff ? <Link to={`/users/${b.user_id}`}>{b.customer_name}</Link> : b.customer_name}</dd><dt>Booking date</dt><dd>{d(b.booking_date)}</dd><dt>Contact</dt><dd>{b.delivery_name} · <a href={`tel:${b.delivery_phone}`}>{b.delivery_phone}</a></dd><dt>Address</dt><dd>{b.delivery_address}</dd><dt>Instructions</dt><dd>{b.special_instructions || '—'}</dd></dl></div>
      <div className="card"><h2>Items</h2><div className="table-wrap"><table><thead><tr><th>Product</th><th className="num">Qty</th><th className="num">Total</th></tr></thead><tbody>
        {b.items.map((i) => <tr key={i.id}><td><div className="cell"><Thumb src={imgUrl(i.image_url)} /><div>{i.name}<small>{i.model_number}</small></div></div></td><td className="num">{i.quantity}</td><td className="num">{money2(i.line_total)}</td></tr>)}</tbody></table></div>
        <p style={{ textAlign: 'right' }}>Booking total (before tax and shipping): <strong>{money2(b.total_amount)}</strong></p></div></div>
    {ask && <Confirm danger={ask.danger} title={ask.title} message={ask.msg} confirmLabel={ask.title} onConfirm={act} onCancel={() => setAsk(null)} />}</>; }}</Async>;
}
