# IoT Data Logger Management System

Full-stack app: **React + Vite** frontend, **Node/Express** REST API, **MySQL** database.
Roles: Admin, Staff, Customer. JWT auth, bcrypt-hashed passwords, role-based access on the backend.

## Requirements
- Node.js 18+ and npm
- MySQL 8+ (or MariaDB 10.5+) running locally, with a user that can create databases

## 1. Backend
```bash
cd backend
npm install
cp .env.example .env        # Windows: copy .env.example .env
# edit .env: set DB_PASSWORD and a long random JWT_SECRET
npm run db:setup            # creates the database + tables and loads demo data
npm start                   # API on http://localhost:5000   (npm run dev to auto-reload)
```
`npm run db:reset` drops the database and rebuilds it with fresh demo data.

## 2. Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173
```
In development Vite proxies `/api` and `/uploads` to port 5000, so no extra config is needed.
For production: `npm run build`, serve `frontend/dist`, set `VITE_API_ORIGIN` to your API origin before building, and set `CLIENT_ORIGIN` in the backend `.env`.

## Demo accounts
| Role | Email | Password |
|---|---|---|
| Admin | admin@iotlogger.com | Admin@123 |
| Staff | staff@iotlogger.com | Staff@123 |
| Customer | rohan@coldchain.in | Customer@123 |

Change these before any real use.

## What each role can do
- **Admin**: everything (products, users and roles, prices/stock, settings, delete records).
- **Staff**: dashboard, bookings, orders, call records, view users/inventory/reports.
- **Customer**: browse catalogue, book, track own bookings and orders, edit own profile.

## Business rules
- A booking checks stock but does not reserve it. Staff confirm it, then **Create order**; stock is deducted inside one transaction with row locks, so simultaneous orders cannot oversell.
- Cancelling an order returns stock. Completed/Cancelled orders are final.
- Order lines snapshot product name, model and price, so later price changes never alter past orders.
- Tax rate and flat shipping come from **Settings** and apply to new orders.
- Every stock change is logged in `inventory_transactions` (Inventory page, "Stock movements").
- Payments are **status tracking only** (method + reference). No card data is collected or stored, and no gateway is integrated.
- Call Members uses `tel:` links, which open the device dialer. The app does not place calls automatically.

## Project layout
```
backend/
  sql/schema.sql            tables, keys, indexes
  scripts/setup.js          schema + demo data (users, products, bookings, orders, calls)
  src/config/db.js          pool + transaction helper
  src/middleware/           auth (JWT, roles), upload (type/size limits), error handling
  src/routes/index.js       all routes
  src/controllers/          auth, users, products, bookings, orders, calls, inventory, reports
  src/services/             bookingService, orderService (transactional logic)
  uploads/                  product images
frontend/src/
  pages/                    Login, Register, Dashboard, Products (+catalogue), ProductForm, ProductDetails,
                            BookingForm, Bookings(+details), Orders(+details), Users, CustomerProfile,
                            Calls (+form), Inventory, Reports, Account (Profile + Settings), NotFound
  components/               Layout (sidebar, top bar, search, notifications, profile menu), ui helpers
```

## API summary (prefix `/api`)
`POST /auth/register|login`, `GET /auth/me`, `PUT /auth/profile|password` ·
`/users` (GET, POST, GET/PUT `/:id`, PATCH `/:id/status`) ·
`/products` (GET public, POST/PUT with `image` multipart, DELETE) ·
`/bookings` (POST, GET, GET `/:id`, PATCH `/:id/status`, POST `/:id/order`) ·
`/orders` (GET, GET `/:id`, PATCH `/:id/status`, PATCH `/:id/payment`) ·
`/calls` (CRUD) · `/inventory/summary|transactions`, `PATCH /inventory/:id` ·
`/reports/dashboard|summary`, `/notifications`, `/settings`.
List endpoints accept `page`, `limit`, `search` and relevant filters.

## End-to-end test checklist
1. Log in as the customer → Catalogue → **Book Now** → submit. Note the booking ID; try a quantity above stock (blocked).
2. Log in as staff → Bookings → open it → **Confirm booking** → **Create order**. Check Inventory: stock dropped and a "Sale" movement appears.
3. Open the order → set status to Processing/Shipped/Completed; record a payment.
4. Cancel a different open order → stock is restored.
5. As admin: Data Loggers → **Add data logger** with a JPG/PNG image (a .txt or >2 MB file is rejected); edit price in Inventory and confirm old orders keep their price.
6. Users: add a user, change role, deactivate (that user can no longer log in), open their history.
7. Call Members: add a record for an existing customer and for a new one; use the phone button; filter by status.
8. Register with an existing email → blocked. Resize the browser to phone width → sidebar becomes a menu.

## Notes
- Password hashing uses `bcryptjs` (pure-JS bcrypt, same algorithm; avoids native build issues on Windows).
- Set a strong `JWT_SECRET`; the server refuses to start with a short one.

## Login page background
The picture is `frontend/public/login-bg.svg`. To use your own photo, put it in `frontend/public/` (e.g. `login-bg.jpg`) and change the `url('/login-bg.svg')` in the `.auth-art` rule in `frontend/src/styles.css`.

## Troubleshooting the server
- `npm start` now prints a clear reason if it cannot start (MySQL not running, wrong password, database missing, port busy, missing `.env`).
- Check `http://localhost:5000/api/health` - it should return `{"status":"ok"}`.
- If product pictures looked broken, run `npm run db:reset` once to regenerate the demo images.
